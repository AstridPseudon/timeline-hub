# Portable owner-film scanner delivery report

## Result

Delivered version `1.0.1` from Agent integration
`4a75f68f32049a69fd86135c645fa64c51175c14` as
`owner_film_cliplook_scan-v1.0.1.zip` and the flat transport candidate
`owner-film-viewing-tools-v1.0.1.tgz`, each with an adjacent bare SHA-256 file.
The scanner is standalone with respect to the
orchestration workspace: it has no predecessor ORCH import, no hardcoded
search roots, no search mode, and requires explicit `--input` and
`--agent-root` arguments. It imports the current Agent's projector,
clip-field/audio-curve helpers, registry, rational-FPS helper, and half-open
duration helpers only after the explicit Agent root is supplied.

The delivery tool itself adds no install step. An owner must provide the
normal qualified Agent Python environment and a matching extracted Agent
checkout; the exact command and setup-document references are in `README.md`.

This is a narrow output-redaction correction. Valid string IDs and pins are
preserved exactly. Malformed object/list/bool/null scope, identity, and
reference fields are never copied to normal, error, or finding reports;
affected findings become `unknown` and closure status becomes `incomplete`.
Reference errors are constant strings and never include exception payloads or
authored values. The v1.0.0 candidate remains preserved and was not
overwritten.

The scanner covers `curve_honoured`, `element_clip_look_overlap`, and
`continuous_audio_fade`. It preserves rational FPS and occurrence/shot/
internal-revision pins; reports unknown metadata explicitly; emits no raw
payload, caption, script, media, credential, or database data; and always sets
`clean_claim: false`. Incomplete closure data is fail-closed as
`status: incomplete`.

The CLI never searches for projects, uses network/socket/database/media/render
operations, or mutates the input. Before writing, it rejects output that is
the input, a symlink, or a hardlink to the input. The owner README makes no
macOS claim and says owner films stay local.

Archive metadata:

The authoritative archive sizes and SHA-256 values are kept outside the
archive in the adjacent bare digest files and `artifact-metadata.json`; they
are intentionally not duplicated here because this report is itself an
archive member. Both archives are below the 20 MB transport limit and contain
the same 11 flat package members in sorted deterministic order.

The exact v1.0.1 manifest, sizes, and SHA-256 values are recorded in the
external `artifact-metadata.json`; the archive member intentionally does not
repeat self-referential hashes.

## Verification

- Qualified targeted tests (the package contains the prior 10 cases plus 8
  bounded-reference regressions):
  `PYTHONPATH=<delivery> /home/user/work/venv-agent/bin/python -m pytest -q <delivery>/tests/test_owner_film_cliplook_scan.py --agent-root <qualified-current-Agent-checkout>`
  — **18 passed**.
- Qualified lint:
  `/home/user/work/venv-agent/bin/ruff check <delivery>/owner_film_cliplook_scan.py <delivery>/tests/test_owner_film_cliplook_scan.py <delivery>/tests/conftest.py`
  — **passed**.
- Qualified syntax:
  `/home/user/work/venv-agent/bin/python -B -m py_compile <delivery>/owner_film_cliplook_scan.py <delivery>/tests/test_owner_film_cliplook_scan.py <delivery>/tests/conftest.py`
  — **passed**.
- Relocated extracted CLI smoke with `env -i PATH=/usr/bin:/bin PYTHONNOUSERSITE=1`,
  explicit `--input`, explicit `--agent-root`, and output in a temporary
  directory — **passed** for valid/unknown, incomplete, and malformed-reference synthetic closures;
  all three categories and `[30000, 1001]` were present for the valid case,
  with `clean_claim: false` in both cases.
- Deterministic ZIP rebuild — **passed**; the repeated digest is recorded in
  the adjacent bare `.sha256` file.
- Deterministic flat TGZ rebuild — **passed**; gzip mtime, tar member order,
  uid/gid, names and member mtimes are fixed and the repeated digest is
  recorded in its adjacent bare `.sha256` file.
- Full/browser/network/socket suites — **not run by instruction**.

No owner-film closure was supplied or uploaded. No production scan or clean
claim was made. Agent canonical-policy review remains required before manager
publication/use; its exact candidate file list is outside the package at
`AGENT-CANONICAL-POLICY-REVIEW-FILELIST.md`.

## Manager handoff

Review the v1.0.1 artifact and then verify each adjacent bare digest with:

```sh
test "$(cat owner_film_cliplook_scan-v1.0.1.sha256)" = "$(sha256sum owner_film_cliplook_scan-v1.0.1.zip | cut -d' ' -f1)"
test "$(cat owner-film-viewing-tools-v1.0.1.sha256)" = "$(sha256sum owner-film-viewing-tools-v1.0.1.tgz | cut -d' ' -f1)"
```

After Agent canonical-policy review, the manager may transport/publish the
flat TGZ and/or ZIP with its adjacent digest. No worker performed hub
publication or supplied owner-film data.
