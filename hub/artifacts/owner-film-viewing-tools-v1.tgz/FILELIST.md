# Delivery file list

Artifacts: `owner_film_cliplook_scan-v1.0.0.zip` and
`owner-film-viewing-tools-v1.tgz`

Package contents:

- `README.md` — owner prerequisites and exact local run command.
- `VERSION` — `1.0.0`.
- `owner_film_cliplook_scan.py` — standalone portable scanner entrypoint.
- `tests/conftest.py` — explicit `--agent-root` pytest option.
- `tests/test_owner_film_cliplook_scan.py` — synthetic portable CLI and semantic smokes.
- `reference/predecessor-ORCHREPORT.md` and `reference/predecessor-owner-film-cliplook-scan.json` — preserved predecessor report/JSON.
- `reference/extension-ORCHREPORT.md` and `reference/extension-owner-film-differences-scan.json` — preserved three-category extension report/JSON.
- `ORCHREPORT.md` — delivery verification report.
- `FILELIST.md` — this manifest.

The adjacent `.sha256` files contain only the SHA-256 digest of their
respective archive. The archives and digests are delivery transport artifacts
and are not included inside either archive. Both archives are flat,
deterministic packages with zeroed member timestamps and uid/gid metadata.
