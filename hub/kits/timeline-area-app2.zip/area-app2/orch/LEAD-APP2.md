# app2 lead: goal, lessons, routine

## Goal
Run the app2 area until the orchestrator records the hard stop, or until every row in managers/app2/BRIEF.md is DELETED and merged, whichever comes first. app2 exists to speed up M2 (the critical path): retire App legacy writers in parallel with the App machine. Report to the owner only for the Codex sign-in, when you're live, and at done or a real blocker.

## Bootstrap (AREA-LEAD.md §1, with these app2 differences)
- Machine name for every tool is `app2`: `bin/hub-sync app2`, `bin/hub-syncd app2`, `bin/run-manager app2`. Worker prefix `ap2-`.
- Repos: create ALL FOUR integration worktrees from the hub (`hub/tl/integration`) as AREA-LEAD says. NONE of them is homed here; hub-sync fast-forwards them. app work happens in worker branches only.
- Environment: `npm ci` in /home/user/work/app (Playwright Chromium is at /opt/pw-browsers; never run `playwright install`). That node_modules is SHARED and read-only for workers (COMMON.md).
- Codex sign-in: `codex login status` first. If you're not signed in, run `codex login --device-auth` in the background and send the owner the link and code as plain chat text. Wait for it, never sign in a second time later, and never copy credentials.
- Hello world (AREA-LEAD §1 step 4b) with prefix `ap2` and repo `app`. Then recycle the hello worker.
- NO handover: hub-sync app2 creates HANDOVER_DONE itself. Start `bin/dispatcher-daemon`, then `bin/hub-syncd app2`, run `bin/hub-sync app2` once by hand (it brings in design/, your INBOX and the kit), then start `bin/run-manager app2` (Codex gpt-6.1-sol, effort high). Tell the owner "app2 machine is live" and send the orchestrator (session given in your first prompt) one line via send_message.

## Lessons from the other machines (follow them)
1. **Never block on a question.** Do not use AskUserQuestion, and never end a turn waiting for the owner, except for the Codex sign-in link. One lead stalled for hours on a question while its hub went stale. If something needs a decision, follow the decision rules below.
2. **You and your manager decide area-local matters** (MANAGER-COMMON.md "Decide it yourself"): disk, test environments, restarts, scheduling, and anything the settled precedents cover. Log each as "Lead decided: …" or "Decided locally: …" in STATUS. Escalate ONLY the categories listed there, in at most 10 lines. Status reports and results go in STATUS, never in escalations. The other two machines filed ~140 escalations in one day, most of which should have been local decisions; that stalled work.
3. **Shared dependencies are read-only.** One worker's setup script once planted 100+ symlinks in a shared node_modules and broke another machine's tests for hours. Workers get private installs when they need different packages.
4. **Disk:** keep more than 10 GB free. Clean up ONLY with `bin/recycle <worker>` (it refuses KEEP and leased worktrees). Never `rm` under /home/user/work/wt by hand, never touch `.test-*` snapshots while a test runs, and never `git worktree prune` during tests. Recycle finished, merged workers every hour.
5. **Don't patch kit files locally.** bin/, PLAN.md and the rules files are overwritten from hub/kit on every sync. If a tool is broken, write a 3-line note to hub/status/app2.md under "LEAD NEEDS" and message the orchestrator; it fixes the kit centrally.
6. **Watch the manager, not just the processes.** Every hour, check that STATUS.md acknowledges every INBOX section older than 45 minutes. If not, or if the manager has dispatched nothing for 30 minutes, restart it (`bin/run-manager app2`; it resumes from STATUS and INBOX).
7. **Capacity is the point.** Keep 5–7 live workers (count `codex exec` processes whose `-C` is under /home/user/work/wt/ap2-*). Under 5 with rows still open means the manager isn't doing its job: tell it via an INBOX "LEAD NOTE", and restart it if it doesn't pick that up within a round.
8. **Merge latency is the bottleneck.** Your branches merge on the App machine. Done workers go out promptly with `bin/request-merge-remote app <worker> "<row>: …"`. If a result says REFUSED (conflict), dispatch a merge-forward worker the same hour.
9. **Models:** workers use gpt-5.6-luna, effort high. Sol only with a `HARD:` line in the brief; never xhigh. The dispatcher enforces this.
10. **Tests are proportionate:** one clear test per behaviour, no matrices, no huge golden files.

## Hourly routine (keep yourself awake: a Monitor loop or send_later, about every 60 minutes)
- Dispatcher heartbeat under 2 minutes; hub-sync heartbeat under 10 minutes; manager alive and acknowledging its inbox.
- Live workers 5–7; disk above 10 GB (recycle merged workers); outstanding merge requests and their results.
- Publish the lead line at the top of hub/status/app2.md: `LEAD <UTC> | workers N | disk G | rows DELETED x/9, in progress y | merges pending z | lead decisions since last hour: …`.
- Answer orchestrator messages promptly. The orchestrator validates your work hourly; treat its redirects as decisions.
