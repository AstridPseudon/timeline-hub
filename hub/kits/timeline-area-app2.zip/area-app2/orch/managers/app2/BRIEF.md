# Manager: App writer retirements, second machine   (worker prefix: ap2-)

**Mission (M2 only):** retire the App legacy writers listed below. For each row: move its consumer onto the one edit path (gesture → EditCommand → Runtime `/v1` commit through the existing door client and outbox), delete the legacy writer, mark the ledger row DELETED with evidence. That is your whole job. Speed matters: M2 is the project's critical path, and App's rows are most of it.

**Why there are two App machines:** the App machine (manager prefix `app-`) keeps every App row already IN PROGRESS plus D02/D08/D10. You take the OPEN rows below. The App machine stays the HOME of the app repo, so your branches merge there (see "Merging").

**Your rows (design/deletion-ledger.app.md / deletion-ledger.md):**
- D01-app-element-routes: runtime/element-adapter direct save/CAS through VideoEditorProvider + ElementsLibraryPanel ingresses
- D01-app-ordinary-batch: useTimelineOps ordinary patches/proposals/project-data/transcript/seam/compiler-canary snapshot ingress
- D01-app-shot-graph-settings: ShotEditorView settings/name direct canonicalShotComposition.publish calls
- D01-app-duplicate: AstridTimelineEditor duplicateIndependentShot → shotComposition.publish graph writer
- D01-app-parent-media: TimelineCommands.addClip/prepared-media and Astrid duplicate-generation snapshot producers
- D01-app-bootstrap: createDefaultTimeline.ts whole-config initialization and headless repair publisher
- D01-app-resolved-edit-serializer: serializeResolvedTimelineEdit legacy resolved-edit serializer
- D01-app-transition-none-serialization: legacy rowsToConfig own-undefined transition / partial-coverage publisher
- D01-app-selected-param: changed selected-pack PARAM snapshot writer (depends on Agent's selected-PARAM original-pin rule: check Agent STATUS first, take it last)
Before starting any row, read hub/status/app.md. If the App manager lists a live worker on that row, skip it and send a PEER REQUEST to App asking which side keeps it.

**You own paths:** only the files those rows touch, in App `src/tools/video-editor/` (not preview/player/render/compositions, which Viewing owns), `src/integrations/runtime/` and `src/sdk/video/timeline/`, plus their tests. If a row needs a change in a shared file that App is also editing (the door client, outbox, commit session, useTimelineOps core), send App a PEER REQUEST and agree who edits it. Never both.

**Key references:** PLAN sections 2 (decisions 3, 6, 7), 3 (App keep/cut) and 6 (gates 5, 6); design/app-writers.md; the per-row notes in the ledger; MANAGER-COMMON.md "Decide it yourself".

**Done for a row:** the consumer emits EditCommands through the existing path; the legacy writer and its now-dead helpers are deleted; the targeted tests of the touched files and their neighbours pass; a zero-legacy-traffic assertion covers the gesture; reload/undo/retry is covered where the row involves persistence. The ledger row is marked DELETED with the merge sha. Tests are proportionate: one clear test per behaviour, no matrices.

**Merging:** you cannot merge into app tl/integration yourself. When a worker is done and your review passes, run `$ORCH/bin/request-merge-remote app <worker> "<row id>: <one line>"`. The App machine's manager does a light conflict/overlap check (you already reviewed it) and merges. Results appear in hub/merge-results/app/<worker>. Keep every branch small and based on the latest hub/tl/integration; on conflict, use bin/merge-forward in the worker's worktree and resend.

**Capacity:** 5–7 live workers. Model: gpt-5.6-luna high for everything; gpt-6.1-sol high only for genuinely hard coupled work, with a `HARD: <reason>` line in the brief. Never xhigh.

**Not yours:** anything outside these rows, M3/M4 work, Composition, the Runtime door, Agent. Never start M5.
