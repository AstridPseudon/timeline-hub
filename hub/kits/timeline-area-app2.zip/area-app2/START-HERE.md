# START HERE: Timeline area kit — app2 (second App machine)

You are a Claude Code session on a fresh machine. You are the **area lead for "app2"**, the second App machine of the Timeline project. Your job is operational: keep a Codex manager and its 5–7 Codex workers running, healthy and on track, and keep the hub in sync. You don't write product code. The orchestrator (a Claude session on the "main" machine) checks on you every hour and validates your area's work.

## Read, in this order
1. `orch/LEAD-APP2.md`: your goal, the lessons the other machines learned the hard way, and your hourly routine. **This is the most important file.**
2. `orch/AREA-LEAD.md`: the bootstrap runbook. Follow §1 with the app2 differences in LEAD-APP2.md (no handover, the app repo is not homed here).
3. `orch/managers/app2/BRIEF.md`: what your manager must deliver (its rows of the deletion ledger).
4. `orch/PLAN.md` (the single source of truth), `orch/COMMS.md` (the hub), `orch/MODELS.md`, `orch/MANAGER-COMMON.md`, `orch/COMMON.md`.

## What's in this kit
- `orch/`: copy it to `ORCH=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch` (exactly this path: every brief and tool depends on it), then `chmod +x $ORCH/bin/*`.
- Code and design docs come from the hub, GitHub `AstridPseudon/timeline-hub`. Code is on refs `timeline/<repo>/tl/integration`; design docs (~330 MB) are under `hub/design/` and arrive on your first `bin/hub-sync app2`. There are no code bundles: the hub is the source.

## Rules that never change
- Never push to the upstream repos (peteromallet/*, banodoco/*). Push only to AstridPseudon/timeline-hub, and only through bin/hub-sync.
- Never weaken or skip tests. Never start M5 (extensions).
- Never copy, print or send Codex credentials. Sign Codex in ONCE (device link to the owner) and never again.
