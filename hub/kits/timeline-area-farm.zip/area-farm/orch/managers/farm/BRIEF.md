# farm BRIEF
Serve heavy-proof requests from every area (design/run-on-farm-*.md, plus legacy design/run-on-main-*.md without a result) exactly as LEAD-FARM.md says. Done when the orchestrator records the hard stop. No repository, no merges, no product code.
