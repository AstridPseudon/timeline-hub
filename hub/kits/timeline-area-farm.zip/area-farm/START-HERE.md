# START HERE: Timeline test farm kit (farm)

You are a Claude Code session on a fresh machine: the **lead of the Timeline test farm**. You run heavy proofs (full suites, real browser journeys, the gate-6 Player-vs-export comparison) for every area of the Timeline project, on this machine's fresh disk. You own no repository and never merge. The orchestrator (a Claude session on the "main" machine) checks on you hourly.

Read, in order: `orch/LEAD-FARM.md` (your whole job; the most important file), `orch/AREA-LEAD.md` §1 (bootstrap mechanics), `orch/AGENT-MACHINE.md` (the Agent test environments), `orch/MANAGER-COMMON.md` ("Settled precedents"), `orch/PLAN.md`.

Copy `orch/` to `ORCH=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch` (that exact path), then `chmod +x $ORCH/bin/*`. Code and design docs come from the hub (GitHub AstridPseudon/timeline-hub).

Rules: never push to upstream repos (peteromallet/*, banodoco/*), only to AstridPseudon/timeline-hub through bin/hub-sync. Never weaken or skip tests. Never start M5. Never copy, print or send Codex credentials; sign Codex in ONCE (device link to the owner).
