"""Shared-shot destination-occupancy probe (read-only audit; temp realms only).

Run (manager, normal authorized executor):
  /home/user/work/venv-agent/bin/python -B \
    /tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/agt-m2-shared-identity-fixture/notes/probe.py

Uses temporary realms under /tmp, the real RuntimeService, the Agent's real commit
provider and the real clip.move capture.  No sockets, no repository writes, no
forged receipts, no product/validator bypass.  Fixture shapes are copied from
Runtime's tests/timeline_commit_film_fixture.py (shot items carry item_id +
media_id + metadata, which _validate_published_shot_payload requires).

Question: a supported clip.move on a SHARED occurrence materializes that occurrence
as a new project shot whose id is the deterministic hash `shot-placement-<sha256>`
(authoring_bundle._authoring_shot_id).  What happens when an unrelated, distinct,
valid shot already occupies exactly that id?

Realms (each fresh):
  control      nothing occupies the destination id.  Positive control: materialize,
               dry-run leaves no trace, retry replays, reload is stable, the same
               occurrence's own re-materialization (second move onto its own id) is
               valid, siblings / other timeline / other project untouched.
  same-project the destination id is pre-occupied by a distinct valid shot published
               in ANOTHER timeline of the same project.
  other-project the destination id is pre-occupied by a distinct valid shot of
               ANOTHER project (also in its own timeline).

Two layers are measured separately and never conflated:
  physical projection   mutable project_shots row, shot_items, shot_revision_heads
  immutable film        the occupant timeline's pinned closure (head, document, history)
                        and every previously accepted revision's closure

Exit status: 0 only if every intended check was reached AND passed (i.e. a refusal
with no state change, or an acceptance that changed nothing unrelated, plus the
control invariants).  1 = every check reached, at least one conformance check
failed (a real finding is in the output).  2 = the probe could not reach every
intended check (setup / API error): NOT a conformance pass.
"""
import copy
import json
import os
import shutil
import sys
import tempfile
import traceback

AGENT = "/home/user/work/wt/agt-m2-shared-identity-fixture"
os.environ.setdefault("ASTRID_RUNTIME_CHECKOUT", "/home/user/work/runtime")
sys.path.insert(0, AGENT)
from tests.helpers.runtime import use_runtime  # noqa: E402

use_runtime()
from runtime_protocol.store import RealmStore  # noqa: E402
from runtime_protocol.service import RuntimeService  # noqa: E402
from runtime_protocol.timeline_commit_port import route_path  # noqa: E402

from astrid.sdk.timeline import commit  # noqa: E402
from astrid.sdk.timeline.capture import capture_move  # noqa: E402

MODES = ("control", "same-project", "other-project")
RESULTS = []
CHECKS = {}  # mode -> {name: {"ok": bool, ...facts}}
INTENDED = {
    "control": ["dest_is_materialized_hash", "dry_run_leaves_no_trace", "dest_matches_prediction",
                "move_accepted", "control_siblings_and_isolation", "retry_replays",
                "reload_identity_stable", "own_rematerialization_valid",
                "history_closure_preserved"],
    "same-project": ["dest_is_materialized_hash", "occupant_precondition", "dry_run_leaves_no_trace",
                     "central_no_unrelated_change", "occupant_film_intact",
                     "siblings_and_isolation"],
    "other-project": ["dest_is_materialized_hash", "occupant_precondition", "dry_run_leaves_no_trace",
                      "central_no_unrelated_change", "occupant_film_intact",
                      "siblings_and_isolation"],
}


def say(name, status, **facts):
    RESULTS.append({"scenario": name, "status": status, **facts})
    print(f"[{status}] {name}")
    for key, value in facts.items():
        print(f"    {key}: {json.dumps(value, sort_keys=True, default=str)[:900]}")


def check(mode, name, ok, **facts):
    """Record one conformance check (ok=True means the invariant held)."""
    CHECKS.setdefault(mode, {})[name] = {"ok": bool(ok), **facts}
    say(f"{mode}: {name}", "PASS" if ok else "FAIL", **facts)


class Incomplete(Exception):
    """A seed/API step the probe depends on did not work; never counted as a pass."""


# --------------------------------------------------------------------------- fixtures

def media(service, project, text, name, kind):
    return service.ingest(project, text.encode(), media_type=kind, original_name=name,
                          idempotency_key=f"m-{project}-{name}")["data"]["object_id"]


def shot_pubs(tag, timeline, shot_id, media_id, item_ids=("item-1",)):
    """One valid shot revision + its internal timeline (clip id `c1` is reused everywhere).

    Items follow Runtime's valid projection shape: item_id (str) + media_id + opaque metadata.
    """
    internal = {
        "timeline_id": timeline, "revision_id": f"int-{tag}",
        "payload": {
            "tracks": [{"id": "picture", "kind": "visual"}],
            "clips": [{"id": "c1", "clipType": "media", "asset": "pic", "at": 0, "hold": 0.25,
                       "track": "picture"}],
            "effects": [], "audio": [], "layout": {},
            "registry": {"assets": {"pic": {"object_id": media_id, "type": "video"}}},
            "assets": [],
        },
    }
    shot = {
        "shot_id": shot_id, "revision_id": f"shot-{tag}",
        "internal_timeline_revision_id": f"int-{tag}",
        "payload": {
            "metadata": {"title": tag, "scene": tag, "opaque": [None, {"keep": tag}]},
            "items": [{"item_id": item_id, "media_id": media_id, "source_frame": index,
                       "metadata": {"role": tag, "opaque": {"keep": [item_id, None]}}}
                      for index, item_id in enumerate(item_ids)],
            "pools": [], "selected_variants": {}, "provenance": {"source_media": media_id},
            "generation_inputs": {}, "audio_bindings": [], "text_bindings": [],
        },
    }
    return internal, shot


def occurrence(occ, shot_id, shot_rev, start_ms):
    return {"occurrence_id": occ, "shot_id": shot_id, "shot_revision_id": shot_rev,
            "placement": {"start_ms": start_ms, "track": "picture"}, "source_offset": 0,
            "duration_ms": 1000, "speed": 1, "track": "picture", "transform": {}, "gain": 1,
            "mute": False, "provenance": {}}


def parent(occurrences):
    return {"config": {"output": {"fps": 24}, "tracks": [{"id": "picture", "kind": "visual", "role": "output"}]},
            "registry": {"assets": {}}, "clips": [], "occurrences": occurrences}


def publish(service, project, timeline, key, rev, internals, shots, occs):
    return service.publish_parent_composition(project, timeline, {
        "project_id": project, "timeline_id": timeline, "expected_head": None,
        "parent_revision_id": rev, "internal_timeline_revisions": internals,
        "shot_revisions": shots, "parent_composition": parent(occs)}, idempotency_key=key)


def build(root):
    """Legacy (pre-commit) heads: two projects, three timelines, shot-a shared by occ-1/occ-2."""
    RealmStore.initialize(root, display_name="Identity probe", realm_id="probe-realm").close()
    service = RuntimeService(root)
    ids, pics = {}, {}
    try:
        for p, name in (("p1", "one"), ("p2", "two")):
            ids[p] = service.create_project({"slug": f"probe-{name}", "name": f"Probe {name}"},
                                            idempotency_key=f"proj-{p}")["id"]
        p1, p2 = ids["p1"], ids["p2"]
        for tl, proj in (("t-main", p1), ("t-alt", p1), ("t-other-project", p2)):
            service.create_timeline(proj, tl, name=tl, idempotency_key=f"tl-{tl}")
        pics = {p: media(service, ids[p], "picture-" + p, "pic.mp4", "video/mp4") for p in ids}
        for proj, shots in ((p1, ("shot-a", "shot-b")), (p2, ("shot-x", "shot-y"))):
            for sid in shots:
                service.create_project_shot(proj, {"shot_id": sid, "name": sid, "metadata": {"seed": sid}},
                                            idempotency_key=f"shot-{sid}")
        ia, sa = shot_pubs("a-main", "t-main", "shot-a", pics["p1"], ("item-a1",))
        ib, sb = shot_pubs("b-main", "t-main", "shot-b", pics["p1"], ("item-b1",))
        publish(service, p1, "t-main", "pub-main", "main-v1", [ia, ib], [sa, sb], [
            occurrence("occ-1", "shot-a", "shot-a-main", 0),
            occurrence("occ-2", "shot-a", "shot-a-main", 1000),
            occurrence("occ-3", "shot-b", "shot-b-main", 2000)])
        # Independently owned occ-1 (same id!) of the same project shot in another timeline.
        ia2, sa2 = shot_pubs("a-alt", "t-alt", "shot-a", pics["p1"], ("item-a1",))
        publish(service, p1, "t-alt", "pub-alt", "alt-v1", [ia2], [sa2],
                [occurrence("occ-1", "shot-a", "shot-a-alt", 0)])
        ix, sx = shot_pubs("x", "t-other-project", "shot-x", pics["p2"], ("item-x1",))
        publish(service, p2, "t-other-project", "pub-other", "other-v1", [ix], [sx], [
            occurrence("occ-1", "shot-x", "shot-x", 0),
            occurrence("occ-2", "shot-x", "shot-x", 1000)])
    finally:
        service.close()
    return ids, pics


def occupy(service, project, timeline, dest, media_id, tag):
    """Publish a distinct, valid, unrelated shot whose id IS `dest`, in its own timeline."""
    service.create_timeline(project, timeline, name=timeline, idempotency_key=f"tl-{tag}")
    service.create_project_shot(project, {"shot_id": dest, "name": f"Occupant {tag}",
                                          "metadata": {"owner": tag}}, idempotency_key=f"shot-{tag}")
    internal, shot = shot_pubs(tag, timeline, dest, media_id, (f"{tag}-item-1", f"{tag}-item-2"))
    publish(service, project, timeline, f"pub-{tag}", f"{tag}-v1", [internal], [shot],
            [occurrence("occ-occupant", dest, shot["revision_id"], 0)])


# --------------------------------------------------------------------------- environment

class Env:
    def __init__(self, root):
        self.service = RuntimeService(root)
        self.n = 0

    def head(self, project, timeline):
        r = self.service.get_project_timeline(project, timeline)
        return {"revision_id": r["head_revision_id"], "publication_id": r["head_publication_id"]}

    def request(self, project, timeline, commands, dry_run=False):
        h = self.head(project, timeline)
        return {"api_version": 1, "project_id": project, "timeline_id": timeline,
                "base_revision_id": h["revision_id"], "base_publication_id": h["publication_id"],
                "commands": commands, "dry_run": dry_run}

    def send(self, project, timeline, request, key):
        return self.service.commit_timeline(
            project, timeline, copy.deepcopy(request), idempotency_key=key,
            publisher="probe-author", invocation_path=route_path(project, timeline),
            authorize=lambda: None)

    def key(self):
        self.n += 1
        return f"probe-{self.n}"

    def closure(self, project, timeline, revision=None):
        revision = revision or self.head(project, timeline)["revision_id"]
        return self.service._timeline_commits()[0].revision_closure(project, timeline, revision)

    def bundle(self, project, timeline):
        return commit.bundle_from_document(self.closure(project, timeline))

    def history(self, project, timeline):
        return self.service.list_timeline_commits(project, timeline, authorize=lambda: None)["items"]

    def snapshot(self, project, timeline):
        return {"head": self.head(project, timeline), "document": self.closure(project, timeline),
                "history": self.history(project, timeline)}

    def shot_state(self, shot_id):
        """Read-only observation of the physical projection of one shot id (any project)."""
        c = self.service.store.conn
        row = c.execute("SELECT * FROM project_shots WHERE id=?", (shot_id,)).fetchone()
        head = c.execute("SELECT project_id, revision_id FROM shot_revision_heads WHERE shot_id=?",
                         (shot_id,)).fetchone()
        return {
            "row": dict(row) if row else None,
            "items": [dict(r) for r in c.execute(
                "SELECT id, media_id, sort_key, source_frame, metadata_json FROM shot_items "
                "WHERE shot_id=? ORDER BY sort_key, id", (shot_id,))],
            "head": dict(head) if head else None,
            "revisions": [r["id"] for r in c.execute(
                "SELECT id FROM shot_revisions WHERE shot_id=? ORDER BY id", (shot_id,))],
        }

    def all_shot_ids(self):
        return [r["id"] for r in self.service.store.conn.execute("SELECT id FROM project_shots ORDER BY id")]

    def move_command(self, project, timeline, ref, on):
        return capture_move(self.bundle(project, timeline), ref, on)

    def close(self):
        self.service.close()


def occ_row(document, occ):
    payload = document["parent_revision"]["payload"]
    return next(o for o in payload["occurrences"] if o["occurrence_id"] == occ)


def clip_of(document, occ, clip="c1"):
    """Authored clip row for (occurrence, clip) in a canonical document, by pinned shot revision."""
    row = occ_row(document, occ)
    shot = next(s for s in document["shot_revisions"] if s["revision_id"] == row["shot_revision_id"])
    internal = next(i for i in document["internal_timeline_revisions"]
                    if i["revision_id"] == shot["internal_timeline_revision_id"])
    return {"shot_id": row["shot_id"], "shot_revision": row["shot_revision_id"],
            "clip": next(c for c in internal["payload"]["clips"] if c["id"] == clip),
            "start_ms": row["placement"]["start_ms"]}


def world(env, timelines):
    return {"timelines": {f"{p}/{t}": env.snapshot(p, t) for p, t in timelines},
            "shots": {sid: env.shot_state(sid) for sid in env.all_shot_ids()}}


def changed(before, after, section):
    return sorted(k for k in before[section] if before[section][k] != after[section].get(k))


def predicted_destination(env, project, timeline, occ):
    """The materialized shot id the provider's real bundle gives `occ` (before any move)."""
    placement = next(p for p in env.bundle(project, timeline)["placements"]
                     if p["occurrence_id"] == occ)
    return placement["shot_id"]


# --------------------------------------------------------------------------- one realm

def run_mode(mode):
    tmp = tempfile.mkdtemp(prefix="shared-identity-fixture-", dir="/tmp")
    env = None
    try:
        ids, pics = build(os.path.join(tmp, "realm"))
        p1, p2 = ids["p1"], ids["p2"]
        env = Env(os.path.join(tmp, "realm"))
        ref = "occurrence:occ-1/clip:c1"

        dest = predicted_destination(env, p1, "t-main", "occ-1")
        sibling_dest = predicted_destination(env, p1, "t-main", "occ-2")
        check(mode, "dest_is_materialized_hash",
              dest.startswith("shot-placement-") and dest not in ("shot-a", sibling_dest),
              destination=dest, sibling_destination=sibling_dest, source_shot="shot-a")

        timelines = [(p1, "t-main"), (p1, "t-alt"), (p2, "t-other-project")]
        occupant = None
        if mode != "control":
            occ_project = p1 if mode == "same-project" else p2
            occ_timeline = "t-occ" if mode == "same-project" else "t-other-occ"
            occupy(env.service, occ_project, occ_timeline, dest, pics["p1" if occ_project == p1 else "p2"],
                   "occ")
            occupant = (occ_project, occ_timeline)
            timelines.append(occupant)
            od = env.closure(*occupant)
            shot_rows = {s["shot_id"] for s in od["shot_revisions"]}
            state = env.shot_state(dest)
            check(mode, "occupant_precondition",
                  shot_rows == {dest} and len(state["items"]) == 2 and state["row"]["project_id"] == occupant[0]
                  and state["head"]["revision_id"] == "shot-occ",
                  occupant_timeline=occupant, occupant_items=[i["id"] for i in state["items"]],
                  occupant_project_row=state["row"] and state["row"]["project_id"],
                  occupant_head=state["head"], occupant_row_metadata=state["row"] and state["row"]["metadata_json"])

        env.service.register_timeline_commit_provider(commit.create_runtime_commit_service())
        before = world(env, timelines)
        occupant_before = before["timelines"].get(f"{occupant[0]}/{occupant[1]}") if occupant else None
        dest_before = before["shots"].get(dest)

        # ---- dry run: must leave no trace at all (and may itself refuse)
        dry_command = env.move_command(p1, "t-main", ref, 0.5)
        try:
            dry = env.send(p1, "t-main", env.request(p1, "t-main", [dry_command], dry_run=True), env.key())
            dry_outcome = {"status": "previewed", "keys": sorted(dry) if isinstance(dry, dict) else str(type(dry))}
        except Exception as exc:  # noqa: BLE001  (measured, reported)
            dry_outcome = {"status": "refused", "type": type(exc).__name__, "code": getattr(exc, "code", None),
                           "message": str(exc)[:300], "details": getattr(exc, "details", None)}
        after_dry = world(env, timelines)
        check(mode, "dry_run_leaves_no_trace", after_dry == before, dry_run=dry_outcome)

        # ---- the real, supported shared-occurrence clip.move
        command = env.move_command(p1, "t-main", ref, 0.5)
        request = env.request(p1, "t-main", [command])
        key = env.key()
        outcome, accepted = {}, None
        try:
            accepted = env.send(p1, "t-main", request, key)
            outcome = {"result": "accepted", "commit_status": accepted["data"].get("status")}
        except Exception as exc:  # noqa: BLE001
            outcome = {"result": "refused", "type": type(exc).__name__, "code": getattr(exc, "code", None),
                       "message": str(exc)[:400], "details": getattr(exc, "details", None)}
        after = world(env, timelines)

        main_key = f"{p1}/t-main"
        others_changed = [k for k in changed(before, after, "timelines") if k != main_key]
        preexisting_shots_changed = changed(before, after, "shots")
        if accepted is not None:
            doc_b, doc_a = before["timelines"][main_key]["document"], after["timelines"][main_key]["document"]
            moved = (clip_of(doc_b, "occ-1")["clip"].get("at"), clip_of(doc_a, "occ-1")["clip"].get("at"))
            actual_dest = occ_row(doc_a, "occ-1")["shot_id"]
            facts_a = {
                "actual_occ1_shot_after": actual_dest,
                "occ1_clip_at_before_after": moved,
                "sibling_occ2_unchanged": clip_of(doc_b, "occ-2") == clip_of(doc_a, "occ-2"),
                "occ3_unchanged": clip_of(doc_b, "occ-3") == clip_of(doc_a, "occ-3"),
                "history_prefix_preserved": after["timelines"][main_key]["history"][:-1]
                == before["timelines"][main_key]["history"],
            }
        else:
            actual_dest, facts_a = None, {}
            # Refusal must be clean: nothing at all changed anywhere.
            facts_a["refusal_changed_nothing"] = after == before
        say(f"{mode}: move outcome", "INFO", **outcome, **facts_a,
            other_timelines_changed=others_changed, preexisting_shots_changed=preexisting_shots_changed)

        dest_after = after["shots"].get(dest)
        if mode == "control":
            check(mode, "move_accepted", accepted is not None, **outcome)
            check(mode, "dest_matches_prediction", accepted is not None and actual_dest == dest,
                  predicted=dest, actual=actual_dest,
                  dest_created=dest_before is None and bool(dest_after and dest_after["row"]))
            check(mode, "control_siblings_and_isolation",
                  accepted is not None and facts_a["sibling_occ2_unchanged"] and facts_a["occ3_unchanged"]
                  and facts_a["history_prefix_preserved"] and not others_changed
                  and not preexisting_shots_changed,
                  **facts_a, other_timelines_changed=others_changed,
                  preexisting_shots_changed=preexisting_shots_changed)
        else:
            occ_key = f"{occupant[0]}/{occupant[1]}"
            projection = {
                "dest_row_before": dest_before["row"], "dest_row_after": dest_after["row"],
                "dest_items_before": [i["id"] for i in dest_before["items"]],
                "dest_items_after": [i["id"] for i in dest_after["items"]],
                "dest_head_before": dest_before["head"], "dest_head_after": dest_after["head"],
                "dest_revisions_before": dest_before["revisions"], "dest_revisions_after": dest_after["revisions"],
            }
            clobbered = dest in preexisting_shots_changed
            film_intact = after["timelines"][occ_key] == occupant_before
            # Distinguish the layers explicitly.
            layers = {
                "physical_projection_changed": clobbered,
                "occupant_items_lost": sorted(
                    {i["id"] for i in dest_before["items"]} - {i["id"] for i in dest_after["items"]}),
                "projection_head_no_longer_occupant_pin": dest_after["head"] != dest_before["head"],
                "immutable_film_occupant_intact": film_intact,
                "occupant_pinned_shot_revision_still_stored": "shot-occ" in dest_after["revisions"],
            }
            central_ok = (accepted is None and after == before) or (accepted is not None and not clobbered)
            classification = ("refused_clean" if accepted is None and after == before
                              else "refused_but_state_changed" if accepted is None
                              else "accepted_physical_projection_overwritten" if clobbered
                              else "accepted_no_unrelated_change")
            check(mode, "central_no_unrelated_change", central_ok, classification=classification,
                  **outcome, **layers, **projection, other_timelines_changed=others_changed)
            check(mode, "occupant_film_intact", film_intact,
                  occupant_head_before=occupant_before["head"], occupant_head_after=after["timelines"][occ_key]["head"],
                  history_equal=after["timelines"][occ_key]["history"] == occupant_before["history"],
                  closure_equal=after["timelines"][occ_key]["document"] == occupant_before["document"],
                  note="immutable pinned closure of the occupant timeline; distinct from the mutable projection")
            unrelated_timelines_changed = [k for k in others_changed if k != occ_key]
            unrelated_shots_changed = [s for s in preexisting_shots_changed if s != dest]
            check(mode, "siblings_and_isolation",
                  not unrelated_timelines_changed and not unrelated_shots_changed
                  and (accepted is None or (facts_a["sibling_occ2_unchanged"] and facts_a["occ3_unchanged"])),
                  other_timelines_changed=others_changed, unrelated_shots_changed=unrelated_shots_changed, **facts_a)

        # ---- retry / reload / own re-materialization (positive control, or accepted occupied runs)
        if accepted is not None:
            first_pub = env.history(p1, "t-main")[-1].get("publication_id")
            first_doc = env.closure(p1, "t-main")
            hist_len = len(env.history(p1, "t-main"))
            try:
                replay = env.send(p1, "t-main", request, key)
                replayed = True
                replay_note = {"identical_envelope": replay == accepted}
            except Exception as exc:  # noqa: BLE001
                replayed, replay_note = False, f"{type(exc).__name__}: {str(exc)[:300]}"
            state_after_retry = {"history_len": len(env.history(p1, "t-main")),
                                 "dest": env.shot_state(dest)}
            if mode == "control":
                check(mode, "retry_replays", replayed and state_after_retry["history_len"] == hist_len
                      and state_after_retry["dest"] == dest_after, replay_note=replay_note)
                reload_dest = predicted_destination(env, p1, "t-main", "occ-1")
                reload_sibling = predicted_destination(env, p1, "t-main", "occ-2")
                check(mode, "reload_identity_stable",
                      reload_dest == dest == actual_dest and reload_sibling == clip_of(first_doc, "occ-2")["shot_id"],
                      reload_dest=reload_dest, reload_sibling=reload_sibling,
                      note="occ-1 now owns the id as an unshared shot; opening it again must not re-hash it")
                second = None
                try:
                    cmd2 = env.move_command(p1, "t-main", ref, 0.75)
                    second = env.send(p1, "t-main", env.request(p1, "t-main", [cmd2]), env.key())
                    err = None
                except Exception as exc:  # noqa: BLE001
                    err = f"{type(exc).__name__} {getattr(exc, 'code', None)}: {str(exc)[:300]}"
                doc2 = env.closure(p1, "t-main")
                check(mode, "own_rematerialization_valid",
                      second is not None
                      and clip_of(doc2, "occ-1")["clip"].get("at") != clip_of(first_doc, "occ-1")["clip"].get("at")
                      and occ_row(doc2, "occ-1")["shot_id"] == dest
                      and clip_of(doc2, "occ-2") == clip_of(first_doc, "occ-2"),
                      error=err, occ1_at=clip_of(doc2, "occ-1")["clip"].get("at"),
                      dest_head_revisions=env.shot_state(dest)["revisions"])
                check(mode, "history_closure_preserved",
                      env.closure(p1, "t-main", first_doc["parent_revision"]["revision_id"]) == first_doc
                      and any(h.get("publication_id") == first_pub for h in env.history(p1, "t-main")),
                      note="the first move's pinned closure is byte-identical after its shot id was re-materialized")
            elif mode == "same-project":
                # Mutual clobbering check: the occupant's own later commit onto the same id.
                try:
                    cmd_o = env.move_command(occupant[0], occupant[1], "occurrence:occ-occupant/clip:c1", 0.5)
                    env.send(occupant[0], occupant[1], env.request(*occupant, [cmd_o]), env.key())
                    occ_err = None
                except Exception as exc:  # noqa: BLE001
                    occ_err = f"{type(exc).__name__} {getattr(exc, 'code', None)}: {str(exc)[:300]}"
                tmain = env.closure(p1, "t-main")
                say(f"{mode}: occupant's own later commit onto the same id", "INFO", error=occ_err,
                    dest_state_now=env.shot_state(dest), t_main_pinned_closure_intact=(
                        tmain == after["timelines"][main_key]["document"]))
    finally:
        if env is not None:
            env.close()
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    incomplete = []
    for mode in MODES:
        try:
            run_mode(mode)
        except Exception as exc:  # noqa: BLE001  report, never hide, never count as pass
            incomplete.append(mode)
            say(f"{mode}: PROBE ABORTED", "ERROR", error=repr(exc), trace=traceback.format_exc()[-1800:])
    missing = {mode: [n for n in INTENDED[mode] if n not in CHECKS.get(mode, {})] for mode in MODES}
    # A control-only check for an occupied run that was refused is not intended; only accepted
    # occupied runs would need more, and those report INFO, not conformance checks.
    incomplete_checks = {m: n for m, n in missing.items() if n}
    failed = {m: [n for n, r in CHECKS.get(m, {}).items() if not r["ok"]] for m in MODES}
    failed = {m: n for m, n in failed.items() if n}
    summary = {"aborted_modes": incomplete, "missing_checks": incomplete_checks, "failed_checks": failed}
    print("SUMMARY " + json.dumps(summary, sort_keys=True))
    if incomplete or incomplete_checks:
        return 2
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
