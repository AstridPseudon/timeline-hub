"""Frozen test-service staging for the inactive PCM helper unit."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

root = Path.cwd()
peers = Path("/home/user/work/runtimes/agent-remotion-0012/node_modules")
files = (
    "attempt-envelope-pcm.mjs",
    "compiled-audio-source-clock.mjs",
    "normal-audio-sources.mjs",
)
tests = (
    "tests/packs/rendering/test_normal_audio_sources.py",
    "tests/packs/rendering/test_normal_audio_source_phase.py",
    "tests/editing_conformance/test_compile_contracts.py",
    "tests/core/rendering/test_service.py",
)
with tempfile.TemporaryDirectory(prefix="agent-pcm-helper-lane-") as temporary:
    overlay = Path(temporary)
    for name in files:
        shutil.copyfile(root / "remotion" / name, overlay / name)
    (overlay / "node_modules").symlink_to(peers, target_is_directory=True)
    environment = dict(os.environ, ASTRID_REMOTION_PROJECT_DIR=str(overlay))
    result = subprocess.run(
        ["/home/user/work/venv-agent/bin/python", "-m", "pytest", "-q",
         "-o", "addopts=", "-p", "no:cacheprovider", "-n", "2", *tests],
        cwd=root,
        env=environment,
        check=False,
    )
raise SystemExit(result.returncode)
