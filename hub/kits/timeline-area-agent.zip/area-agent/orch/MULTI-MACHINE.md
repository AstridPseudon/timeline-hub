# Multi-machine design (orchestrator decision, 2026-10-19; owner approved using AstridPseudon/timeline-hub as transport) — the owner GitHub account was renamed from HannahSubmarine to AstridPseudon; the local origin may still say HannahSubmarine (GitHub redirects)

Machines:
- **main** (this one): the orchestrator (Claude), plus the Runtime and Agent managers. Home of the agent and runtime repos.
- **app**: a remote Claude session acting as App area lead, running the App manager plus its Codex workers. Home of the app repo.
- **viewing**: a remote Claude session acting as Viewing area lead, running the Viewing manager plus its Codex workers. Home of the composition repo.
Each machine runs its own dispatcher with the same bin/ tools and the same paths (/home/user/work/..., the same ORCH path), so briefs stay valid.

Hub = GitHub AstridPseudon/timeline-hub:
- Code: refs `timeline/<repo>/<branch>` (for example timeline/agent/tl/integration, timeline/app/tl/app-m1-move). The home machine pushes `tl/integration` for its repos. Every machine pushes its own workers' `tl/*` branches. R4 frozen refs are pushed once as `timeline/<repo>/r4/<name>`.
- Files: branch `main`, folder `hub/`:
  - `hub/status/<area>.md`: the manager's STATUS.md plus the lead's one-line health. Written by the owning machine.
  - `hub/inbox/<area>.md`: orchestrator → manager. Written by main.
  - `hub/escalations/<area>-*.md`: written by the area. Main mirrors them into $ORCH/escalations/ and moves answered ones to `hub/escalations/closed/`.
  - `hub/design/*`: shared design docs, mirrored both ways with $ORCH/design/.
  - `hub/merge-requests/<repo>/<worker>`: a non-home machine asks the repo's home to merge timeline/<repo>/tl/<worker>. The home fetches it, queues MERGE through its normal queue, and writes the result to `hub/merge-results/<repo>/<worker>`.
  - `hub/kit/`: the orchestration kit: PLAN, COMMON, MANAGER-COMMON, AUDIT-BRIEF, bin/, managers/<area>/BRIEF.md, AREA-LEAD.md.
- `bin/hub-sync` runs every ~3 minutes on every machine (pull --rebase, then push, retrying on races). Each machine writes only its own files; design/ is last-writer-wins per file.
- Never push to the real upstream repos. The delivery is still the ZIP, built on main.
- Codex credentials are never copied by tools. Each remote lead signs in with `codex login --device-auth` and the owner approves the link.
