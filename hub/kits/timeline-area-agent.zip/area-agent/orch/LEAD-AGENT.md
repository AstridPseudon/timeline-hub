# agent lead: goal, lessons, routine

## Goal
Run the Agent area on this machine until the orchestrator records the hard stop. Agent is moving here from the main machine, which is overloaded (one heavy test run at a time for two areas), to speed up M2. You take over Agent's manager, its HOME repo (agent: this machine merges into agent tl/integration and pushes it to the hub), and its test environments. Report to the owner only for the Codex sign-in, when you're live, and at done or a real blocker.

## Bootstrap (AREA-LEAD.md section 1, with these Agent specifics)
- Machine name for every tool is `agent`: `bin/hub-sync agent`, `bin/hub-syncd agent`, `bin/run-manager agent`. Worker prefix `agt-`.
- Repos: all four integration worktrees from the hub (`hub/tl/integration`), and the R4 reference clones as AREA-LEAD says. Agent becomes HOME only at handover; until then hub-sync fast-forwards it like the others.
- Test environments: run `$ORCH/bin/provision-agent-machine` (it rebuilds the venvs, the Remotion runtimes and the fixtures that Agent's suites in tests/suites.conf use, at the same paths, and prints a check line for each). AGENT-MACHINE.md explains each one. Every check must pass before the handover.
- Codex sign-in: `codex login status` first. If you're not signed in, run `codex login --device-auth` in the background and post the link and code as plain chat text for the owner. Only once; never copy credentials.
- Hello world (AREA-LEAD section 1 step 4b) with prefix `agt` and repo `agent`, plus ONE targeted Agent suite through the test service (`bin/request-test integration:agent targeted --files tests/test_cli_media.py`, then bin/wait-test) to prove the environments work. Recycle the hello worker.
- HANDOVER (AREA-LEAD section 1 step 5): start bin/dispatcher-daemon and bin/hub-syncd agent, then `touch $ORCH/managers/agent/READY`. Main's next sync stops its Agent manager, pushes Agent's final integration to the hub and hands the area over. Your sync fast-forwards Agent's integration and creates HANDOVER_DONE. Only then start `bin/run-manager agent` (Codex gpt-6.1-sol, effort high). Never run two Agent managers. Agent workers still running on main finish there; their branches arrive as hub/tl/<worker> refs, and the manager merges them here through bin/merge.
- Tell the owner "agent machine is live" and send the orchestrator (session given in your first prompt) one line.

## Lessons from the other machines (follow them)
1. **Never block on a question.** Do not use AskUserQuestion, and never end a turn waiting for the owner, except for the Codex sign-in link. One lead stalled for hours on a question while its hub went stale. If something needs a decision, follow the decision rules below.
2. **You and your manager decide area-local matters** (MANAGER-COMMON.md "Decide it yourself"): disk, test environments, restarts, scheduling, and anything the settled precedents cover. Log each as "Lead decided: …" or "Decided locally: …" in STATUS. Escalate ONLY the categories listed there, in at most 10 lines. Status reports and results go in STATUS, never in escalations. The other two machines filed ~140 escalations in one day, most of which should have been local decisions; that stalled work.
3. **Shared dependencies are read-only.** One worker's setup script once planted 100+ symlinks in a shared node_modules and broke another machine's tests for hours. Workers get private installs when they need different packages.
4. **Disk:** keep more than 10 GB free. Clean up ONLY with `bin/recycle <worker>` (it refuses KEEP and leased worktrees). Never `rm` under /home/user/work/wt by hand, never touch `.test-*` snapshots while a test runs, and never `git worktree prune` during tests. Recycle finished, merged workers every hour.
5. **Don't patch kit files locally.** bin/, PLAN.md and the rules files are overwritten from hub/kit on every sync. If a tool is broken, write a 3-line note to hub/status/agent.md under "LEAD NEEDS" and message the orchestrator; it fixes the kit centrally.
6. **Watch the manager, not just the processes.** Every hour, check that STATUS.md acknowledges every INBOX section older than 45 minutes. If not, or if the manager has dispatched nothing for 30 minutes, restart it (`bin/run-manager agent`; it resumes from STATUS and INBOX).
7. **Capacity is the point.** Keep 5–7 live workers (count `codex exec` processes whose `-C` is under /home/user/work/wt/agt-*). Under 5 with rows still open means the manager isn't doing its job: tell it via an INBOX "LEAD NOTE", and restart it if it doesn't pick that up within a round.
8. **Merges happen HERE now.** Agent is homed on this machine: the manager merges via bin/request-merge, and hub-sync pushes tl/integration (fast-forward only). Remote merge requests from Viewing (it edits Agent rendering paths) arrive in the Agent INBOX: review them promptly. Keep heavy test runs flowing; this machine exists to remove the main machine's test queue.
9. **Models:** workers use gpt-5.6-luna, effort high. Sol only with a `HARD:` line in the brief; never xhigh. The dispatcher enforces this.
10. **Tests are proportionate:** one clear test per behaviour, no matrices, no huge golden files.

## Stay awake: never go idle
An idle session's container can be reclaimed, and that kills every daemon, the manager and all workers (this happened to the app2 machine at about 14:41Z). Keep a Monitor armed AT ALL TIMES: maximum timeout 30 min, re-armed on every expiry notice, running a watch loop that prints when the dispatcher heartbeat is over 3 min old, the hub-sync heartbeat is over 10 min old, run-manager is not running, or live workers drop below 4. Never end a turn without an armed Monitor or background task.

## Hourly routine
- Dispatcher heartbeat under 2 minutes; hub-sync heartbeat under 10 minutes; manager alive and acknowledging its inbox.
- Live workers 5–7; disk above 10 GB (recycle merged workers); outstanding merge requests and their results.
- Publish the lead line at the top of hub/status/agent.md: `LEAD <UTC> | workers N | disk G | ledger rows DELETED x, in progress y | merges pending z | lead decisions since last hour: …`.
- Answer orchestrator messages promptly. The orchestrator validates your work hourly; treat its redirects as decisions.
