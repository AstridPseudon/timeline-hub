# Agent test environments on a fresh machine
Run `$ORCH/bin/provision-agent-machine [--verify-only] [--list] [NAME...]` (idempotent; needs network). Existing envs are only
verified, never modified; a failed build is removed and reported. Prereqs: git curl tar xz, `python3.13` (3.13.x; or PYTHON313=),
clones /home/user/work/agent and /home/user/work/runtime on tl/integration (`hub` remote is added if missing). Exit 0 = all CHECK lines OK.
Agent commits: A008=cbd91c3b A010=fc6c1f26 A012=5f6c8130 ACUR=7970544b A013=30da0a5e (`git fetch hub` if absent). All paths below under /home/user/work.

| Env (path) | Source | How | Verify (CHECK line) |
|---|---|---|---|
| toolchain/node-v20.19.4-linux-x64 | nodejs.org tarball sha256 7a488a09... | curl + tar -xJ (npm 10.8.2 bundled) | node -v, npm -v |
| venv-agent | tests/provision/venv-agent.txt (163 pins incl. 2 git pins: ArtAgents@242f9c43 timeline-schema, runpod-lifecycle@db793455) | python3.13 -m venv; pip install pip/setuptools/wheel; pip install --no-deps -r freeze | pip freeze == file; import pytest, xdist, banodoco_timeline_schema |
| venv-agent-child | venv-agent-child.txt (= venv-agent pins + astrid) | same, then `pip install --no-deps` of `git archive` of Agent 86405964 (non-editable) | freeze == file; import astrid, astrid_runtime_client |
| venv-agent-child-s2 | venv-agent-child-s2.txt | same, astrid from Agent d8749a9c (client contract 0.2.13) | same |
| runtimes/agent-remotion (0.0.8) | A008 remotion/{package.json,package-lock.json,.npmrc,patches,scripts} + artifacts/0.0.8.tgz | `npm ci` under toolchain node, empty src/ | lock bytes == A008 blob; composition 0.0.8, remotion 4.0.509 |
| deps/agent-remotion-0.0.8 | same as above minus fetch-shared-browser.mjs and src/ | npm ci | same |
| runtimes/agent-remotion-0010 | A010 files; artifacts 0.0.10 (A010) + 0.0.8 (A008, unused leftover) | npm ci | lock == A010 blob; composition 0.0.10 |
| runtimes/agent-remotion-0012 | A012 files; artifacts 0.0.12 + leftovers 0.0.10, 0.0.8 | npm ci | lock == A012 blob (cca94d49...); composition 0.0.12 |
| runtimes/agent-remotion-current | whole `remotion/` of ACUR (+ .source-commit) | npm ci (lock == 0012's, so node_modules identical), write node_modules/.astrid-package-lock.sha256 | lock == ACUR blob; marker files; `node --check` |
| runtimes/agent-remotion-0013 | whole `remotion/` of A013 (lock sha c4d7030b...), files chmod a-w | npm ci (as bin/make-runtime) | lock == A013 blob; composition 0.0.13 |
| fixtures/vibecomfy | github.com/peteromallet/VibeComfy.git @ 31f90bb03d33 detached | clone, checkout, push URL disabled, chmod -R a-w | git rev-parse HEAD, clean |
| wt/rt-pin-{20207411,2c4ac180,7d1cfa6b,94114269,a0dca169,a6a11a80}, wt/rt-m2-track-public-export (6be97063), wt/rt-m2-null-speed-clean-candidate (4c145dc6) | Runtime repo commit named in the dir (full sha in script) | `git -C runtime worktree add --detach` after `git fetch hub` | git rev-parse HEAD == sha, clean |

Every runtime CHECK also compares node_modules/.package-lock.json with the sha256 recorded from the source machine's install
(61e6ef1d.. 0.0.8, ee426da6.. 0010, 27515b4e.. 0012+current, e207343a.. 0013), so an npm-ci drift is caught.
The env files tests/agent-remotion*.env and suites.conf need no change: the paths are identical.

Not reproduced / caveats
- Source dirs of the two child venvs (wt/.child-install, wt/.orch-astrid-<sha>) are gone; rebuilt from `git archive` of the logged commits. On this machine the rebuilt astrid package is byte-identical to the installed one (child checked).
- `.astrid-registry-state.json` and runtimes/*/src/*.generated.ts are written by renders/tests, not seeded; the first run regenerates them.
- No browser is provisioned (none on the source machine either); real renders use Remotion's own download or ASTRID_REMOTION_BROWSER_EXECUTABLE (/opt/pw-browsers).
- Not provisioned (not Agent-suite deps): venv-runtime (runtime suites), /home/user/work/node-v20.19.4-linux-x64{,.tar.xz} duplicates, app/composition clones, other wt/* worktrees.
- Suite lines pinning `runtime rev-parse HEAD == 388eff42` expect that exact Runtime clone state; the script does not move the clone.
- Rehearsed here in a scratch root (W=... AGENT=... RUNTIME=...): node, 0010, current, vibecomfy, venv-agent-child built and verified; --verify-only on this machine passes except markers/null-speed. venv-agent, child-s2, 0.0.8, deps, 0012, 0013 and worktree creation were not rebuilt.
