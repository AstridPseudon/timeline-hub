"""Bounded Discord command action."""
