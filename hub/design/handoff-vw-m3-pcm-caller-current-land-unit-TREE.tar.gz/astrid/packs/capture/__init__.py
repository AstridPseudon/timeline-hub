"""Astrid capture pack."""
