"""Astrid Editorial pack."""
