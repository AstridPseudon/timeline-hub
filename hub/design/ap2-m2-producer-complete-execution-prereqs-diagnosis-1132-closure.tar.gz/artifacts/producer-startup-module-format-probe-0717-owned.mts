import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const appRoot = path.resolve(process.argv[2] ?? '');
assert.ok(appRoot, 'module-format probe requires the exact App source root');

const harnessModule = await import(
  pathToFileURL(path.join(appRoot, 'tests/e2e/local/support/harness.ts')).href,
);
const { DirectHarness } = harnessModule as typeof import('/home/user/work/app/tests/e2e/local/support/harness.ts');
assert.equal(typeof DirectHarness, 'function', 'DirectHarness module export');
await Promise.resolve();
console.log('module-format probe PASS: DirectHarness loaded as ESM; no daemon invoked');
