#!/bin/sh
set -eu

RUN_ROOT=${1:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}
DURABLE_ROOT=${2:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}
CHILD_LOG=${3:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}
CHILD_STATUS=${4:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}
APP_ROOT=${5:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}
RUN_MODE=${6:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}
AGENT_SHA=${7:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}
RUNTIME_SHA=${8:?usage: $0 RUN_ROOT DURABLE_ROOT CHILD_LOG CHILD_STATUS APP_ROOT RUN_MODE AGENT_SHA RUNTIME_SHA}

case "$RUN_ROOT:$DURABLE_ROOT:$CHILD_LOG:$APP_ROOT" in
  /*:/*:/*:/*) ;;
  *) echo 'retention paths must be absolute' >&2; exit 2 ;;
esac
test "$RUN_MODE" = ordinary
test "$CHILD_STATUS" -ne 0
test -d "$RUN_ROOT"
test "$(realpath "$RUN_ROOT")" = "$RUN_ROOT"
test -d "$RUN_ROOT/browser-output"
test -f "$CHILD_LOG"
test ! -e "$DURABLE_ROOT"
mkdir "$DURABLE_ROOT"
test "$(realpath "$DURABLE_ROOT")" = "$DURABLE_ROOT"
if test -n "$(find "$RUN_ROOT/browser-output" -type l -print -quit)"; then
  echo 'refusing symlinked browser failure output' >&2
  exit 1
fi

# Keep the complete Playwright output tree, including error-context.md and
# trace.zip. Do not copy the run environment, caches, profiles, or credentials.
cp -a "$RUN_ROOT/browser-output" "$DURABLE_ROOT/browser-output"
cp -p "$CHILD_LOG" "$DURABLE_ROOT/child.log"

find "$DURABLE_ROOT/browser-output" -type f -name error-context.md -print -quit | grep -q .
find "$DURABLE_ROOT/browser-output" -type f -name trace.zip -print -quit | grep -q .

{
  printf '%s\n' 'producer failure evidence v1'
  printf 'child_status=%s\n' "$CHILD_STATUS"
  printf 'run_mode=%s\n' "$RUN_MODE"
  printf 'source_app_root=%s\n' "$(realpath "$APP_ROOT")"
  printf 'source_head=%s\n' "$(git -C "$APP_ROOT" rev-parse HEAD)"
  printf 'source_tree=%s\n' "$(git -C "$APP_ROOT" show -s --format=%T HEAD)"
  printf 'agent_head=%s\n' "$AGENT_SHA"
  printf 'runtime_head=%s\n' "$RUNTIME_SHA"
  printf '%s\n' 'child_command=npm run test:e2e:three-products -- --grep M2 ordinary extension batch'
  printf '%s\n' 'playwright_command=playwright test --config playwright.producer-ownership-current-pin.config.ts tests/e2e/local/producer-ownership-current-pin.spec.ts'
  printf '%s\n' 'child_log=child.log'
  printf '%s\n' 'browser_output=browser-output/'
} > "$DURABLE_ROOT/identity.txt"

(
  cd "$DURABLE_ROOT"
  find . -type f ! -name SHA256SUMS -print \
    | LC_ALL=C sort \
    | while IFS= read -r path; do
        sha256sum -- "$path"
      done
) > "$DURABLE_ROOT/SHA256SUMS"
test -s "$DURABLE_ROOT/SHA256SUMS"
