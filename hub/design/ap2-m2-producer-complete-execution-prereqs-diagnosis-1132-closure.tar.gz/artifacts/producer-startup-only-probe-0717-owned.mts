import assert from 'node:assert/strict';
import { existsSync, lstatSync, renameSync, realpathSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const appRoot = path.resolve(process.argv[2] ?? '');
assert.ok(appRoot, 'startup probe requires the exact App source root');

const harnessModule = await import(pathToFileURL(path.join(appRoot, 'tests/e2e/local/support/harness.ts')).href);
const { DirectHarness } = harnessModule as typeof import('/home/user/work/app/tests/e2e/local/support/harness.ts');

function assertPhysicalChain(rawPath: string, label: string, requireLeaf: boolean): void {
  const absolute = path.resolve(rawPath);
  const parsed = path.parse(absolute);
  let current = parsed.root;
  for (const component of absolute.slice(parsed.root.length).split(path.sep).filter(Boolean)) {
    current = path.join(current, component);
    if (!existsSync(current)) {
      assert.equal(requireLeaf, false, `${label} missing at ${current}`);
      break;
    }
    assert.notEqual(lstatSync(current).isSymbolicLink(), true, `${label} traverses symlink at ${current}`);
    assert.equal(realpathSync(current), current, `${label} is not physical at ${current}`);
  }
}

async function assertPlantedRealmSymlinkRefused(): Promise<void> {
  const harness = new DirectHarness();
  let startupError: unknown;
  try {
    await harness.start({
      seed: false,
      beforeRuntimeStart: async (candidate: typeof harness) => {
        const physicalRealm = `${candidate.realmDir}.physical`;
        renameSync(candidate.realmDir, physicalRealm);
        symlinkSync(physicalRealm, candidate.realmDir);
        assertPhysicalChain(physicalRealm, 'planted physical realm', true);
      },
    });
  } catch (error) {
    startupError = error;
  } finally {
    await harness.stop();
  }
  assert.ok(startupError, 'Runtime accepted a planted realm-root symlink');
  assert.match(String(startupError), /symlink|startup|Runtime exited/i, 'Runtime refusal did not identify startup failure');
  console.log('startup negative PASS: planted realm-root symlink refused by Runtime');
}

async function assertPhysicalRuntimeStartsHealthy(): Promise<void> {
  const harness = await new DirectHarness().start({ seed: false });
  try {
    assertPhysicalChain(tmpdir(), 'TMPDIR', true);
    assertPhysicalChain(harness.tmp, 'harness temp root', true);
    assertPhysicalChain(harness.realmDir, 'realm root', true);
    assertPhysicalChain(harness.supportDir, 'support root', true);
    assertPhysicalChain(harness.credentialPath, 'product credential', true);
    assertPhysicalChain(harness.auditPath, 'door audit path', false);

    const runtimeHealth = await fetch(`${harness.runtimeUrl}/v1/health`);
    assert.equal(runtimeHealth.status, 200, 'Runtime direct health');
    const healthBody = await runtimeHealth.json() as { runtime_instance_id?: string };
    assert.ok(healthBody.runtime_instance_id, 'Runtime health instance identity');

    const runtimeRealm = await harness.runtimeJson<{ realm_id?: string; version?: number }>('GET', '/v1/realm');
    assert.equal(runtimeRealm.status, 200, 'Runtime direct realm');
    assert.equal(runtimeRealm.body.realm_id, harness.realmId, 'Runtime direct realm identity');
    assert.equal(runtimeRealm.body.version, 1, 'Runtime direct realm version');

    const doorHealth = await harness.doorRequest('/v1/health');
    assert.equal(doorHealth.status, 200, 'Runtime door health');
    const doorHealthBody = doorHealth.json() as { runtime_instance_id?: string };
    assert.equal(doorHealthBody.runtime_instance_id, harness.runtimeInstanceId, 'Runtime door health instance identity');
    const doorRealm = await harness.doorRequest('/v1/realm');
    assert.equal(doorRealm.status, 200, 'Runtime door realm');
    const doorRealmBody = doorRealm.json() as { realm_id?: string; version?: number };
    assert.equal(doorRealmBody.realm_id, harness.realmId, 'Runtime door realm identity');
    assert.equal(doorRealmBody.version, 1, 'Runtime door realm version');
    console.log(`startup positive PASS: physical root healthy realm=${harness.realmId} runtime=${healthBody.runtime_instance_id}`);
  } finally {
    await harness.stop();
  }
}

await assertPlantedRealmSymlinkRefused();
await assertPhysicalRuntimeStartsHealthy();
console.log('startup-only smoke PASS: no browser, Vite, build, producer body, or producer case invoked');
