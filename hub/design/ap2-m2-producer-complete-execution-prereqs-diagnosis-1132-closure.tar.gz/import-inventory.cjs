// Parse source as data. Never import App, Vite config, probe, or control code.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {createRequire, isBuiltin} = require('node:module');
const ts = require('/home/user/work/app/node_modules/typescript');
const picomatch = require('/home/user/work/app/node_modules/picomatch');
const root = __dirname;
const keeper = '/home/user/work/wt/app-pin-5863411a';
const graph = path.join(root, '../../workers/ap2-m2-locked-app-test-graph/artifacts/app-ap2-m2-locked-graph/node_modules');
const agentRepo = '/home/user/peteromallet/astrid-agent';
const agentRef = '8130a401bf44a518d5a40ae274d398b8c560be55';
const agentInputs = JSON.parse(fs.readFileSync(path.join(root,'agent-parse-input.json'),'utf8'));
const agentFiles = new Set(fs.readFileSync(path.join(root,'agent-source-tree.tsv'),'utf8').trim().split('\n').map(line=>line.split('\t')[1]));
const virtual = '/FROZEN_AGENT/';
function exists(file) { return file.startsWith(virtual) ? agentFiles.has(file.slice(virtual.length)) : fs.existsSync(file) && fs.statSync(file).isFile(); }
function read(file) { return file.startsWith(virtual) ? Buffer.from(agentInputs[file.slice(virtual.length)] || '', 'base64') : fs.readFileSync(file); }
function candidate(file) {
  const choices = [file, ...['.ts','.tsx','.js','.jsx','.mjs','.cjs','.mts','.json','.css','.d.ts'].map(ext=>file+ext),
    ...['index.ts','index.tsx','index.js','index.mjs'].map(entry=>path.join(file,entry))];
  if (/\.js$/.test(file)) choices.push(file.slice(0,-3)+'.ts',file.slice(0,-3)+'.tsx');
  return choices.find(exists);
}
function resolve(file, name) {
  if (isBuiltin(name)) return {kind:'node-builtin', target:name};
  if (/^(https?:|data:)/.test(name)) return {kind:'external-url',target:name};
  if (name === 'virtual:astrid-element-admissions') return {kind:'generated-virtual-module',target:'config/vite/astridElementAdmissions.ts:154'};
  name = name.split('?')[0];
  let local;
  if (name.startsWith('.')) local = path.resolve(path.dirname(file),name.split('?')[0]);
  else if (name.startsWith('@/')) local = path.join(keeper,'src',name.slice(2));
  else if (name === '@astrid/editor-sdk') local = path.join(keeper,'src/sdk/index.ts');
  else if (name.startsWith('@astrid-public/')) local = path.join(keeper,'vendor/astrid-browser/astrid',name.slice(15));
  else if (name.startsWith('@astrid/')) local = path.join(virtual,'astrid',name.slice(8));
  else if (name === '@banodoco/timeline-schema') local = path.join(keeper,'vendor/timeline-schema/typescript/dist/src/index.js');
  if (local) return {kind:'source',target:candidate(local) || local,exists:!!candidate(local)};
  // Resolve through the selected graph for App/Agent imports; package internals
  // resolve from their actual shared physical importer, matching Node symlinks.
  const importer = file.startsWith(keeper) || file.startsWith(virtual) || file.startsWith(root)
    ? path.join(graph, '../package.json') : file;
  try {
    const resolved = createRequire(importer).resolve(name);
    return {kind:'package',target:fs.realpathSync(resolved),exists:true};
  } catch (error) {
    if (error.code === 'ERR_PACKAGE_PATH_NOT_EXPORTED') {
      const parts = name.split('/');
      const pkg = name.startsWith('@') ? parts.slice(0,2).join('/') : parts[0];
      const sub = name.slice(pkg.length);
      const dir = path.join(graph,pkg);
      try {
        const manifest = JSON.parse(fs.readFileSync(path.join(dir,'package.json'),'utf8'));
        let entry = manifest.exports?.[sub ? '.'+sub : '.'];
        while (entry && typeof entry === 'object') entry = entry.import ?? entry.node ?? entry.browser ?? entry.default;
        if (typeof entry === 'string' && exists(path.join(dir,entry))) return {kind:'package-esm-static',target:fs.realpathSync(path.join(dir,entry)),exists:true};
      } catch {}
    }
    return {kind:'conditional-or-unresolved',target:name,error:error.code};
  }
}
const seeds = [
  'config/vite/vite.config.ts','scripts/build-hosted.mjs','tests/e2e/local/global-setup.ts',
  'playwright.producer-ownership-current-pin.config.ts','tests/e2e/local/producer-ownership-current-pin.spec.ts',
  'tests/e2e/local/support/harness.ts','src/app/main.tsx',
].map(p=>path.join(keeper,p));
for (const name of ['producer-startup-only-probe-0717-owned.mts','producer-startup-module-format-probe-0717-owned.mts']) seeds.push(path.join(root,'artifacts',name));
for (const pkg of ['tsx/dist/cli.mjs','tsx/dist/loader.mjs','vite/dist/node/index.js','@playwright/test/cli.js','@banodoco/timeline-composition/dist/evaluation.js']) seeds.push(fs.realpathSync(path.join(graph,pkg)));
const pending = [...seeds], visited = new Set(), files = [], edges = [], dynamic = [];
const appFiles = fs.readFileSync(path.join(root,'app-source-tree.tsv'),'utf8').trim().split('\n').map(line=>path.join(keeper,line.split('\t')[1]));
while (pending.length) {
  const file = pending.pop();
  if (visited.has(file)) continue;
  visited.add(file);
  if (!exists(file)) { files.push({file,missing:true}); continue; }
  const bytes = read(file);
  files.push({file,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length});
  if (!/\.(?:[cm]?[jt]sx?)$/.test(file) || /\.d\.ts$/.test(file)) continue;
  const ast = ts.createSourceFile(file, bytes.toString(), ts.ScriptTarget.Latest, true);
  function add(node,name,kind) {
    const result = resolve(file,name);
    edges.push({file,line:ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1,specifier:name,syntax:kind,...result});
    if (result.exists && /\.(?:[cm]?[jt]sx?|json|css)$/.test(result.target)) pending.push(result.target);
  }
  function walk(node) {
    if (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) {
      if (node.moduleSpecifier && ts.isStringLiteral(node.moduleSpecifier)) add(node,node.moduleSpecifier.text,node.isTypeOnly || node.importClause?.isTypeOnly ? 'type-only':'import/export');
    } else if (ts.isCallExpression(node)) {
      const text = node.expression.getText(ast);
      if (text === 'import' || text === 'require' || text === 'import.meta.glob') {
        const arg = node.arguments[0];
        if (text === 'import.meta.glob') {
          const patterns = arg && ts.isStringLiteralLike(arg) ? [arg.text] : arg && ts.isArrayLiteralExpression(arg) ? arg.elements.filter(ts.isStringLiteralLike).map(e=>e.text) : [];
          const expanded = patterns.map(pattern=>pattern.startsWith('@astrid/') ? path.join(virtual,'astrid',pattern.slice(8)) : pattern.startsWith('/') ? path.join(keeper,pattern) : path.resolve(path.dirname(file),pattern));
          const matches = expanded.length ? [...appFiles,...[...agentFiles].map(name=>virtual+name)].filter(p=>picomatch(expanded)(p)) : [];
          dynamic.push({file,line:ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1,expression:node.getText(ast).slice(0,300),staticGlobMatches:matches});
          for (const target of matches) {
            edges.push({file,line:ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1,specifier:target,syntax:'expanded glob',kind:'source',target,exists:true});
            if (/\.(?:[cm]?[jt]sx?)$/.test(target)) pending.push(target);
          }
        }
        else if (arg && ts.isStringLiteralLike(arg)) add(node,arg.text,text);
        else dynamic.push({file,line:ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1,expression:node.getText(ast).slice(0,300)});
      }
    }
    ts.forEachChild(node,walk);
  }
  walk(ast);
}
fs.writeFileSync(path.join(root,'import-inventory.json'),JSON.stringify({
  method:'TypeScript AST static superset, includes type-only/conditional edges. CJS resolution inventory is not executed Vite/ESM proof. Nonliteral imports explicitly retained.',
  seeds,files,edges,dynamic,
},null,2)+'\n');
console.log(JSON.stringify({files:files.length,edges:edges.length,nonliteral:dynamic.length,unresolved:edges.filter(e=>e.kind==='conditional-or-unresolved').length,missing:files.filter(f=>f.missing).length}));
