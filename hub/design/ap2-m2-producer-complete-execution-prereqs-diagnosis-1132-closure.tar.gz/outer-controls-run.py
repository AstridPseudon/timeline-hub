#!/usr/bin/env python3
"""Launch the registered run command through all real shell dispatch bodies.

Fixture translation is limited to absolute paths and their transitive SHA values.
External source/build/graph/lock tools are stubs; no guard source is removed.
No browser, build, install, socket, or shared-install write is permitted.
"""
from pathlib import Path
import difflib, hashlib, json, os, shutil, subprocess, sys, tempfile
ROOT = Path(__file__).resolve().parent
ORCH = ROOT.parent.parent
OLD = ORCH/'workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts'
KEEPER = '/home/user/work/wt/app-pin-5863411a'
HEAD = '5863411a8c2400db719b5385002b05af0a2b3891'
TREE = '31b0f77c6ef4e9fdbeff3e4f88cc4705f0891e89'
AGENT = '8130a401bf44a518d5a40ae274d398b8c560be55'
ATREE = '236c3e57e0265c52b81ba8085de3193026176bff'
RUNTIME = '2c4ac180c2220bdad966bc01e95ad230e99ce26a'
RTREE = '7ab412cc4bcbe517efcfa806e092336390312e18'
sha = lambda b: hashlib.sha256(b).hexdigest()
NAMES = [p.name for p in (ROOT/'artifacts').iterdir()]
ORDER = ['producer-retain-failure-artifacts-0753.sh', 'producer-public13-runner-0717-owned.sh',
 'producer-runner-0717-owned.sh','producer-physical-keeper-gate-0717-owned.sh',
 'producer-startup-only-probe-0717-owned.mts','producer-startup-module-format-probe-0717-owned.mts',
 'producer-startup-only-gate-0717-owned.sh','producer-startup-custody-gate-0717-owned.sh']
registration = next(l for l in (ORCH/'tests/suites.conf').read_text().splitlines()
 if l.startswith('app ap2-m2-producer-next-diagnostic-guard-and-case-0812-integration '))
stored_command = registration.split(' ', 2)[2]
command = subprocess.check_output(['awk', '-v', 'r=app', '-v', 's=ap2-m2-producer-next-diagnostic-guard-and-case-0812-integration', '$1==r && $2==s {$1=$2=""; sub(/^ +/,""); print; exit}', str(ORCH/'tests/suites.conf')], text=True).rstrip('\n')
(ROOT/'stored-command.sh').write_text(stored_command+'\n')
(ROOT/'registered-command.sh').write_text(command+'\n')
(ROOT/'registration.sha256').write_text(sha((registration+'\n').encode())+'  original registration line including LF\n')

# The stub source is kept separately so its operations can be inspected.
STUB = ROOT/'launch-tool-stub.py'

def control(label, source, mode):
 case = ROOT/'controls'/label
 case.mkdir(parents=True, exist_ok=False)
 with tempfile.TemporaryDirectory(prefix='launch-', dir=case) as tmp:
  t = Path(tmp); app = t/'keeper'; app.mkdir(); (t/'tmp').mkdir()
  chain = t/'workers'/source.parent.name/'artifacts'; chain.mkdir(parents=True); binpath = t/'bin'; binpath.mkdir()
  # Fixture files are real copies; all writes stay here. Shared node_modules
  # is only an initial/restored symlink, never written through.
  for n in ['package.json','scripts/testing/run-producer-public13-list.sh',
            'tests/e2e/local/producer-ownership-current-pin.spec.ts',
            'tests/e2e/local/support/producer-ownership-current-pin.ts',
            'playwright.producer-ownership-current-pin.config.ts']:
   dest=app/n; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(Path(KEEPER)/n,dest)
  (app/'node_modules').symlink_to('/home/user/work/app/node_modules')
  agent=t/'agent-source'; runtime=t/'runtime-source'
  (agent/'.git').mkdir(parents=True); (runtime/'.git').mkdir(parents=True)
  keep=t/'KEEP'; keep.touch(); durable=chain.parent/'evidence'
  (t/'workers/ap2-m2-locked-app-test-graph').symlink_to(ORCH/'workers/ap2-m2-locked-app-test-graph')
  mapping=[('/home/user/work/wt/app-pin-09171792',str(app)),
    (KEEPER,str(app)),
    ('/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-helper-expect-import-0717/KEEP',str(keep)),
    ('/home/user/work/wt/ap2-m2-producer-helper-expect-import-0717',str(app)),
    ('/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/app-pin-09171792/KEEP',str(keep)),
    ('/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/app-pin-5863411a/KEEP',str(keep)),
    ('/home/user/peteromallet/astrid-agent',str(agent)),
    ('/home/user/banodoco/banodoco-workspace-runtime',str(runtime)),
    (str(ORCH/'workers/ap2-m2-producer-helper-expect-import-0717/KEEP'),str(keep)),
    (str(source),str(chain)), (str(source.parent/'evidence'),str(durable)),
    ('ORCH='+str(ORCH), 'ORCH='+str(t)),
    ('$ORCH/workers/ap2-m2-locked-app-test-graph',str(ORCH/'workers/ap2-m2-locked-app-test-graph'))]
  data={n:(source/n).read_text() for n in NAMES}
  for n in NAMES:
   for a,b in mapping:data[n]=data[n].replace(a,b)
  hashes=[]
  for n in ORDER:
   oldhash=sha((source/n).read_bytes()); newhash=sha(data[n].encode())
   f=chain/n; f.write_text(data[n]);f.chmod(0o755)
   if oldhash!=newhash:
    hashes.append((oldhash,newhash))
    for other in NAMES:
     if other!=n:data[other]=data[other].replace(oldhash,newhash)
  # Assert no dispatch, guards, argv, shell bodies, or helper behavior changed.
  for n in NAMES:
   reverse=(chain/n).read_text()
   for a,b in reversed(hashes):reverse=reverse.replace(b,a)
   for a,b in reversed(mapping):reverse=reverse.replace(b,a)
   assert reverse==(source/n).read_text(),n
  cmd=command
  # Translate old registration to the selected chain before fixture rebinding.
  if source!=OLD:
   cmd=cmd.replace(str(OLD),str(source))
   cmd=cmd.replace(sha((OLD/ORDER[-1]).read_bytes()),sha((source/ORDER[-1]).read_bytes()))
  production_cmd=cmd
  for a,b in mapping:cmd=cmd.replace(a,b)
  for a,b in hashes:cmd=cmd.replace(a,b)
  reverse=cmd
  for a,b in reversed(hashes):reverse=reverse.replace(b,a)
  for a,b in reversed(mapping):reverse=reverse.replace(b,a)
  assert reverse==production_cmd
  (case/'fixture-translation.json').write_text(json.dumps({'paths':mapping,'hashes':hashes},indent=2)+'\n')
  (case/'fixture-command.sh').write_text(cmd+'\n')
  for name in ['git','node','npm','flock','sh','mktemp','cp']:(binpath/name).symlink_to(STUB)
  # Shared graph is never altered; private package copies are populated by
  # the node stub at the existing graph-construction child boundary.
  case_head = HEAD if source == ROOT/'artifacts' else '6b0267c62aa8773132f1496d5014279e6c1edf61'
  case_tree = TREE if source == ROOT/'artifacts' else 'c1ac3383624322ae8d67b10dee36965670d91cd7'
  cmd=cmd.replace('6b0267c62aa8773132f1496d5014279e6c1edf61',case_head)
  cmd=cmd.replace('c1ac3383624322ae8d67b10dee36965670d91cd7',case_tree)
  cfg={'app':str(app),'agent':str(agent),'runtime':str(runtime),'mode':mode,
       'audit':str(case/'dispatch.jsonl'),'temps':str(case/'temps.jsonl'),
       'stub':str(STUB),'bin':str(binpath),'durable':str(durable),
       'head':case_head,'tree':case_tree,'agent_head':AGENT,'agent_tree':ATREE,
       'runtime_head':RUNTIME,'runtime_tree':RTREE,'source_wrapper':str(app/'scripts/testing/run-producer-public13-list.sh')}
  config=t/'config.json';config.write_text(json.dumps(cfg))
  env=dict(os.environ,PATH=str(binpath)+':'+os.environ['PATH'],CONTROL_CONFIG=str(config),TMPDIR=str(t/'tmp'))
  result=subprocess.run(['/bin/bash','-c',cmd],cwd=app,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
  (case/'output.txt').write_text(result.stdout)
  assert result.returncode==(0 if mode=='success' else 1),(label,result.returncode,result.stdout)
  assert not (app/'.public13-effective-ordinary').exists()
  assert not (app/'dist').exists()
  assert os.readlink(app/'node_modules')=='/home/user/work/app/node_modules'
  events=[json.loads(l) for l in (case/'dispatch.jsonl').read_text().splitlines()]
  shells=[e for e in events if e['tool']=='sh' and e['args'] and e['args'][0]!='-c']
  executed=[Path(e['args'][0]).name for e in shells]
  if label=='before':
   assert executed==[ORDER[-1]],executed
  else:
   assert executed[:4]==[ORDER[-1],ORDER[3],ORDER[2],ORDER[1]],executed
  # npm forwarder must really dispatch build + test; fake npm only handles
  # build, while the real wrapper executes the fake Playwright executable.
  children=[e for e in events if e['tool']=='playwright']
  if label=='before':
   assert not children,children
   assert sum(e['tool']=='build-stub' for e in events)==0
  else:
   assert len(children)==1,children
   assert children[0]['args']==['test','--config','playwright.producer-ownership-current-pin.config.ts','tests/e2e/local/producer-ownership-current-pin.spec.ts']
   assert sum(e['tool']=='build-stub' for e in events)==1
  temps=[json.loads(l) for l in (case/'temps.jsonl').read_text().splitlines()]
  leaked=[p for p in temps if Path(p).exists()]
  if label=='before':
   assert len(leaked)==1 and Path(leaked[0]).name.startswith('tl-ap2-producer-existing-'),leaked
  else:assert not leaked,leaked
  packets=list(durable.glob('failure-*')) if durable.exists() else []
  manifest=False
  if mode=='failure' and label!='before':
   assert len(packets)==1
   packet=packets[0]
   assert (packet/'browser-output/nested/error-context.md').read_bytes()==b'representative complete DOM context\n'
   assert (packet/'browser-output/nested/trace.zip').read_bytes()==b'PK\x03\x04representative trace bytes\n'
   assert (packet/'child.log').read_text()=='planted Playwright child\n  1 failed\n'
   assert 'child_status=1\n' in (packet/'identity.txt').read_text()
   check=subprocess.run(['/usr/bin/sha256sum','-c','SHA256SUMS'],cwd=packet,capture_output=True,text=True)
   assert check.returncode==0,check.stdout+check.stderr
   (case/'manifest-check.txt').write_text(check.stdout)
   shutil.copytree(packet,case/'packet');manifest=True
  elif label=='before':assert not packets
  elif mode=='success':assert not packets
  else:
   assert 'producer failure retention FAILED status=' in result.stdout,result.stdout
   assert all(not (p/'SHA256SUMS').exists() for p in packets)
  # Audit contains only explicit argv/path/status values, never environment.
  summary={'label':label,'outer_status':result.returncode,'manifest':manifest,
   'dispatch':executed,'shell_executions':len(shells),'child_count':len(children),
   'temps_created':len(temps),'temps_leaked':len(leaked),'translation_reverse':'PASS',
   'run_root_removed':True,'dist_removed':True,'node_modules_restored':True}
  (case/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  for p in leaked:shutil.rmtree(p)
  print(json.dumps(summary))

if __name__=='__main__':
 controls=ROOT/'controls'
 assert not controls.exists(),'Do not overwrite prior evidence'
 control('before',OLD,'failure')
 for label,mode in [('after','failure'),('absent-output','absent'),('copy-failure','copy-failure'),('success','success')]:
  control(label,ROOT/'artifacts',mode)
 print('outer controls PASS count=5 browser=0 build=0 daemon=0 socket=0 shared_writes=0')
