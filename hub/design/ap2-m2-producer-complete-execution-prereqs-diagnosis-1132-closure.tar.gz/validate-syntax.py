"""Syntax only; never execute either command closure."""
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
for name in ['outer-controls-run.py', 'launch-tool-stub.py', 'prepare-closure.py', 'audit-inputs.py', 'prepare-parser-input.py', 'validate-syntax.py']:
    compile((root / name).read_bytes(), str(root / name), 'exec')
    print('PASS in-memory Python compile', name)
for folder in ['artifacts', 'before-artifacts']:
    for path in sorted((root / folder).glob('*.sh')):
        subprocess.run(['sh', '-n', str(path)], check=True)
        print('PASS sh -n', path.relative_to(root))
    for path in sorted((root / folder).glob('*.mts')):
        subprocess.run(['node', '--check', str(path)], check=True)
        print('PASS node --check', path.relative_to(root))
for path in sorted(root.glob('*.sh.txt')):
    subprocess.run(['sh', '-n', str(path)], check=True)
    print('PASS sh -n', path.name)
subprocess.run(['node', '--check', str(root / 'import-inventory.cjs')], check=True)
print('PASS node --check import-inventory.cjs')
