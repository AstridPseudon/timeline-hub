#!/usr/bin/python3
"""Strict, launch-only child stubs. Unknown tool invocations fail closed."""
import json, os, pathlib, shutil, subprocess, sys
P=pathlib.Path
c=json.loads(P(os.environ['CONTROL_CONFIG']).read_text())
tool=P(sys.argv[0]).name;args=sys.argv[1:]
def audit(name,args):
 with open(c['audit'],'a') as f:f.write(json.dumps({'tool':name,'args':args})+'\n')
def fail():
 print('unexpected launch stub invocation: '+tool+' '+repr(args),file=sys.stderr);sys.exit(99)
def real(name,args):os.execv('/usr/bin/'+name,[name]+args)
audit(tool,args)
if tool=='sh':
 os.execv('/bin/sh',['sh']+args)
elif tool=='git':
 a=args;repo=None
 if a[:1]==['-C']:repo=a[1];a=a[2:]
 if a[:1]==['clone']:
  target=P(a[-1]);(target/'.git').mkdir(parents=True);(target/'remotion').mkdir();sys.exit(0)
 if a[:2]==['reset','--hard']:sys.exit(0)
 if a[:1]==['status'] or a[:1]==['diff'] or a[:1]==['ls-files'] or a[:2]==['merge-base','--is-ancestor']:sys.exit(0)
 if a[:1]==['rev-parse']:
  ref=a[-1]
  if ref=='HEAD':
   key='agent_head' if repo and 'agent' in repo and repo!=c['app'] else 'runtime_head' if repo and 'runtime' in repo else 'head'
   print(c[key]);sys.exit(0)
  if ref.endswith('^{commit}'):print(ref[:-9]);sys.exit(0)
 if a[:1]==['show']:
  if '--format=%T' in a:
   ref=a[-1]
   print('d63fe4f1e1f32a01acfc9d11cda6c29066fce162' if ref.startswith('17d2518c') else 'd908845dbc8e5ebf96698d08621557e904f20c52' if ref.startswith('36dd9125') else c['agent_tree'] if ref.startswith(c['agent_head']) or repo and ('agent-source' in repo or '/.public13-effective-ordinary/agent' in repo)
      else c['runtime_tree'] if ref.startswith(c['runtime_head']) or repo and ('runtime-source' in repo or '/.public13-effective-ordinary/runtime' in repo)
      else c['tree']);sys.exit(0)
  if '--format=%P' in a:
   print('b8cc7e1c79ec5516b9eee3832b5c33d62dac1aa7' if a[-1].startswith(c['head']) else '17d2518c341c47a2d8634047b400399886da3a2a');sys.exit(0)
  if a[-1]=='HEAD:scripts/testing/run-producer-public13-list.sh':
   sys.stdout.write(P(c['source_wrapper']).read_text());sys.exit(0)
  if a[-1].endswith(':contract/artifacts.json'):
   print('{}');sys.exit(0)
 fail()
elif tool=='node':
 if args[:1]==['-p']:print('0.0.13');sys.exit(0)
 body=sys.stdin.read()
 if args[:1]==['--input-type=commonjs']:print('75');sys.exit(0)
 if args==['--input-type=module','-']:
  if 'SOURCE_NODE_MODULES' in os.environ:
   dest=P(os.environ['PRIVATE_NODE_MODULES']);(dest/'.bin').mkdir(exist_ok=True)
   # Only private executable entries. No link is added to the shared graph.
   (dest/'.bin/playwright').symlink_to(c['stub'])
   (dest/'.bin/vite').symlink_to('/usr/bin/true')
   src=P(os.environ['SOURCE_NODE_MODULES'])/'@banodoco/timeline-composition'
   for f in ['package.json','dist/evaluation.js']:
    d=dest/'@banodoco/timeline-composition'/f;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/f,d)
  else:print('launch-only resolver stub (not source/ESM evidence)')
  sys.exit(0)
 fail()
elif tool=='npm':
 if args==['run','build:hosted']:
  audit('build-stub',args)
  d=P.cwd()/'dist';d.mkdir();(d/'index.html').write_text('launch stub\n');sys.exit(0)
 fail()
elif tool=='playwright':
 # Called by the actual npm-forwarder branch after real argv validation.
 expected=['test','--config','playwright.producer-ownership-current-pin.config.ts','tests/e2e/local/producer-ownership-current-pin.spec.ts']
 if args!=expected:fail()
 root=P(os.environ['PLAYWRIGHT_OUTPUT_DIR']);assert root.is_dir()
 assert str(root).startswith('/tmp/tla-') and '/a/.public13-effective-ordinary/browser-output' in str(root)
 assert str(root)!=str(root.resolve()),'must exercise the real short-symlink path'
 audit('output-path', [str(root),str(root.resolve()),os.environ['PRODUCER_PUBLIC13_LIST_LOG'],os.environ['PRODUCER_PUBLIC13_DURABLE_ROOT']])
 if c['mode']!='absent' and c['mode']!='success':
  d=root/'nested';d.mkdir();(d/'error-context.md').write_bytes(b'representative complete DOM context\n');(d/'trace.zip').write_bytes(b'PK\x03\x04representative trace bytes\n')
 print('planted Playwright child')
 print('  1 passed' if c['mode']=='success' else '  1 failed')
 sys.exit(0 if c['mode']=='success' else 1)
elif tool=='flock':
 if args==['-n','/home/user/work/.app-m1-browser.lock','true']:sys.exit(0)
 if args[:3]==['-w','600','/home/user/work/.app-m1-browser.lock']:
  os.execvp(args[3],args[3:])
 fail()
elif tool=='mktemp':
 r=subprocess.run(['/usr/bin/mktemp']+args,text=True,capture_output=True)
 if r.returncode==0:
  with open(c['temps'],'a') as f:f.write(json.dumps(r.stdout.strip())+'\n')
 sys.stdout.write(r.stdout);sys.stderr.write(r.stderr);sys.exit(r.returncode)
elif tool=='cp':
 if c['mode']=='copy-failure' and args[:1]==['-a']:
  print('planted cp failure',file=sys.stderr);sys.exit(23)
 real('cp',args)
else:fail()
