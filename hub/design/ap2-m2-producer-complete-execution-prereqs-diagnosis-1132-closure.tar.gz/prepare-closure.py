"""Data-only closure repair. Never executes producer or control code."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
ORCH = ROOT.parent.parent
PRIOR = ORCH / 'workers/ap2-m2-producer-complete-control-closure-1122'
LIVE = ORCH / 'workers/ap2-m2-producer-new-topology-main-binding-1113'
KEEPER = Path('/home/user/work/wt/app-pin-5863411a')
GRAPH = ORCH / 'workers/ap2-m2-locked-app-test-graph/artifacts/app-ap2-m2-locked-graph'
SOURCE = '5863411a8c2400db719b5385002b05af0a2b3891'
TREE = '31b0f77c6ef4e9fdbeff3e4f88cc4705f0891e89'
BASE = '17d2518c341c47a2d8634047b400399886da3a2a'
PARENT = 'b8cc7e1c79ec5516b9eee3832b5c33d62dac1aa7'
ORDER = ['producer-retain-failure-artifacts-0753.sh', 'producer-public13-runner-0717-owned.sh',
         'producer-runner-0717-owned.sh', 'producer-physical-keeper-gate-0717-owned.sh',
         'producer-startup-only-probe-0717-owned.mts', 'producer-startup-module-format-probe-0717-owned.mts',
         'producer-startup-only-gate-0717-owned.sh', 'producer-startup-custody-gate-0717-owned.sh']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(KEEPER), *args], text=True).strip()

assert git('rev-parse', 'HEAD') == SOURCE
assert git('show', '-s', '--format=%T', 'HEAD') == TREE
assert git('show', '-s', '--format=%P', SOURCE) == PARENT
assert git('show', '-s', '--format=%P', PARENT) == BASE
assert not git('status', '--porcelain=v1', '--untracked-files=all')
expected_files = {
    'scripts/testing/run-producer-public13-list.sh': '329cfca7ff6fcc6764e5eaa6cb53ba77a40e6aa842361d0ed6795ca5b4398352',
    'tests/e2e/local/producer-ownership-current-pin.spec.ts': '6666c0365d13f302725788e6fbfcce9e0fb283e4b30c40661886522a67f270e6',
    'tests/e2e/local/support/producer-ownership-current-pin.ts': 'df1faac404b69efa8a5fb06297814e6ca3b5d52b4a5856633706c7ac2e3ae949',
    'playwright.producer-ownership-current-pin.config.ts': '5b880ceff883abce2575a3a85aaa4eda69d3bcb848768ff0e91f337d50cca4c0',
}
for name, expected in expected_files.items():
    assert sha((KEEPER / name).read_bytes()) == expected, name
shared = Path('/home/user/work/app/node_modules')
assert str(shared.resolve()) == str(shared)
tsx = {
    'dist/cli.mjs': '8729ecfb90d9d568939e4190e6f1d3317c946583b7d37a776e0c23a21c021cf8',
    'dist/loader.mjs': '0b1c5b86192772fe9257710e739959cee5947c11ae1f93b61abfaa9b80c6def1',
    'package.json': '6e764b21991c21595441f82387c1451ccd10a3e7a3f0973cc5e3649a12dea7d2',
}
for name, expected in tsx.items():
    assert sha((shared / 'tsx' / name).read_bytes()) == expected
assert (shared / '.bin/tsx').resolve() == (shared / 'tsx/dist/cli.mjs').resolve()
assert os.access(shared / '.bin/tsx', os.X_OK)
assert json.loads((GRAPH / 'node_modules/@banodoco/timeline-composition/package.json').read_text())['version'] == '0.0.13'
assert sha((GRAPH / 'node_modules/@banodoco/timeline-composition/package.json').read_bytes()) == '7c806b078b00bba1593336c49a3d2953b3f8f7afc7fa9919f6d5d7ccc7c1aa61'
assert sha((GRAPH / 'node_modules/@banodoco/timeline-composition/dist/evaluation.js').read_bytes()) == 'e27ed545e9e0c28cf863e7bccd4a720f61e1002e04f2946dd3afca5e5f478155'
assert git('check-ignore', 'node_modules') == 'node_modules'
link = KEEPER / 'node_modules'
assert not link.exists() and not link.is_symlink(), 'Do not replace an existing dependency path'
link.symlink_to(shared)
assert os.readlink(link) == str(shared)
assert not git('status', '--porcelain=v1', '--untracked-files=all')
(ROOT / 'keeper-repair.json').write_text(json.dumps({
    'operation': 'restore absent ignored symlink only', 'path': str(link), 'target': str(shared),
    'source': SOURCE, 'tree': TREE, 'parent': PARENT, 'baseline': BASE,
    'source_hashes': expected_files, 'shared_tsx_hashes': tsx,
    'composition_source': str(GRAPH / 'node_modules/@banodoco/timeline-composition'),
    'shared_install_modified': False, 'keeper_tracked_or_untracked_delta': '',
}, indent=2) + '\n')

# Rebind all positive absolute worker paths together, then hash from leaves upward.
mapping = [(str(LIVE), str(ROOT)),
           ('$ORCH/workers/' + LIVE.name, '$ORCH/workers/' + ROOT.name)]
data = {name: (PRIOR / 'artifacts' / name).read_text() for name in ORDER}
for name in ORDER:
    assert (PRIOR / 'artifacts' / name).read_bytes() == (LIVE / 'artifacts' / name).read_bytes()
    for old, new in mapping:
        data[name] = data[name].replace(old, new)
hashes = []
for name in ORDER:
    old = sha((PRIOR / 'artifacts' / name).read_bytes())
    new = sha(data[name].encode())
    path = ROOT / 'artifacts' / name
    path.write_text(data[name])
    path.chmod(0o755)
    if old != new:
        hashes.append((old, new))
        for other in ORDER:
            if other != name:
                data[other] = data[other].replace(old, new)
for name in ORDER:
    reverse = (ROOT / 'artifacts' / name).read_text()
    for old, new in reversed(hashes):
        reverse = reverse.replace(new, old)
    for old, new in reversed(mapping):
        reverse = reverse.replace(new, old)
    assert reverse == (PRIOR / 'artifacts' / name).read_text(), name
for name in ['outer-controls-run.py', 'launch-tool-stub.py']:
    shutil.copy2(PRIOR / name, ROOT / name)
assert sha((ROOT / 'launch-tool-stub.py').read_bytes()) == '4299795135db4be3b83b41d9034cb1519b529925865222f9af866029df9264b7'
(ROOT / 'rebind-proof.json').write_text(json.dumps({
    'path_replacements': mapping, 'computed_hash_replacements': hashes,
    'reverse': {name: 'PASS' for name in ORDER},
    'harness_and_stub': 'byte-identical to 1122; before assertion NOT repaired',
}, indent=2) + '\n')
print('PASS source/ancestry/clean/dependency checks; restored original keeper link; eight data-only artifact reverse proofs; exact harness+stub')
