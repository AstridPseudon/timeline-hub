"""Read-only inventory; does not source or execute the guarded command."""
from pathlib import Path
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
ORCH = ROOT.parent.parent
KEEPER = Path('/home/user/work/wt/app-pin-5863411a')
GRAPH = ORCH / 'workers/ap2-m2-locked-app-test-graph/artifacts/app-ap2-m2-locked-graph'
ARCHIVE = GRAPH.parent / 'app-ap2-m2-locked-graph-source.tar'

def digest(path):
    with open(path, 'rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def command(*args):
    result = subprocess.run(args, capture_output=True, text=True)
    return {'argv': list(args), 'status': result.returncode, 'stdout': result.stdout.strip(), 'stderr': result.stderr.strip()}

def info(path):
    p = Path(path)
    out = {'path': str(p), 'exists': p.exists(), 'realpath': str(p.resolve()),
           'link': os.readlink(p) if p.is_symlink() else None}
    if p.is_file():
        out.update(sha256=digest(p), size=p.stat().st_size)
    return out

template = json.loads((ORCH / 'workers/ap2-m2-producer-all-bound-hash-edges-repair-0945/bound-hash-readback.json').read_text())
old_root = str(ORCH / 'workers/ap2-m2-producer-all-bound-hash-edges-repair-0945')

def rebound(value):
    return value.replace(old_root, str(ROOT)).replace('/home/user/work/wt/app-pin-09171792', str(KEEPER))

constants = {}
for p in (ROOT / 'artifacts').iterdir():
    constants[p.name] = dict(re.findall(r'^([A-Z_]+)=([0-9a-f]{40,64}|sha256:[0-9a-f]{64})$', p.read_text(), re.M))
with tarfile.open(ARCHIVE) as archive:
    tgz = archive.extractfile('vendor/artifacts/banodoco-timeline-composition-0.0.13.tgz').read()
with tarfile.open(fileobj=io.BytesIO(tgz), mode='r:gz') as package:
    archive_members = [m for m in package if m.isfile()]
    composition_files = {m.name: hashlib.sha256(package.extractfile(m).read()).hexdigest() for m in archive_members}
rows = []
for row in template['hash_guards']:
    name, key = row['artifact'], row['guard']
    expected = constants[name][key]
    target = rebound(row['target'])
    if row.get('kind') in ('git-commit', 'git-tree'):
        arg = '--format=%H' if row['kind'] == 'git-commit' else '--format=%T'
        ref = constants[name].get(key.replace('TREE', 'SHA').replace('FINAL_SHA', 'FINAL_HEAD'), expected)
        if key == 'FINAL_TREE':
            ref = constants[name]['FINAL_HEAD']
        result = command('git', '-C', target, 'show', '-s', arg, ref)
        actual = result['stdout'] if result['status'] == 0 else result['stderr']
    elif key == 'COMPOSITION_TARBALL_SHA':
        actual = hashlib.sha256(tgz).hexdigest()
    else:
        actual = digest(target) if Path(target).is_file() else 'MISSING'
    rows.append({'artifact': name, 'guard': key, 'target': target, 'expected': expected, 'actual': actual, 'match': expected == actual})
paths = [info(rebound(row['target'])) | {'artifact': row['artifact'], 'guard': row['guard']} for row in template['path_guards']]
# Evidence root is created by runner:230-231, not required to preexist.
for row in paths:
    row['required_before_execution'] = row['guard'] != 'EVIDENCE_ROOT'
contract_raw = subprocess.check_output(['git', '-C', '/home/user/banodoco/banodoco-workspace-runtime', 'show',
    '2c4ac180c2220bdad966bc01e95ad230e99ce26a:contract/artifacts.json'])
contract = json.loads(contract_raw)
readback = {'hash_guards': rows, 'path_guards': paths, 'value_guard': {
    'expected': constants['producer-runner-0717-owned.sh']['PRODUCER_SHA'], 'actual': contract['version'],
    'artifact_count': len(contract['artifacts']), 'sha256': hashlib.sha256(contract_raw).hexdigest()},
    'composition_archive_files': composition_files, 'composition_archive_file_count': len(archive_members),
    'source_archive': info(ARCHIVE), 'composition_tgz_sha256': hashlib.sha256(tgz).hexdigest()}
(ROOT / 'guard-readback.json').write_text(json.dumps(readback, indent=2) + '\n')
assert len(rows) == 51 and len(paths) == 20
assert all(r['match'] for r in rows), [r for r in rows if not r['match']]
assert all(r['exists'] for r in paths if r['required_before_execution'])
assert contract['version'] == constants['producer-runner-0717-owned.sh']['PRODUCER_SHA'] and len(contract['artifacts']) == 75
assert len(archive_members) == 77

packages = []
bins = {}
issues = []
non_packages = []
for top in sorted((GRAPH / 'node_modules').iterdir()):
    if top.name == '.bin':
        continue
    children = sorted(top.iterdir()) if top.name.startswith('@') else [top]
    for p in children:
        manifest = p / 'package.json'
        if not p.exists():
            issues.append(['missing-package', str(p)])
            continue
        if not manifest.is_file():
            # The existing construction loop explicitly continues on ENOENT.
            non_packages.append(info(p))
            continue
        data = json.loads(manifest.read_text())
        packages.append(info(manifest) | {'name': data.get('name'), 'version': data.get('version'),
            'dependencies': data.get('dependencies', {}), 'optionalDependencies': data.get('optionalDependencies', {})})
        declaration = data.get('bin', {})
        if isinstance(declaration, str):
            declaration = {data['name'].split('/')[-1]: declaration}
        for name, relative in declaration.items():
            target = p / relative
            bins.setdefault(name, []).append(info(target))
            if not target.is_file() or not os.access(target, os.X_OK):
                issues.append(['bad-bin', name, str(target)])
all_top = [info(p) for p in sorted((GRAPH / 'node_modules').iterdir())]
(ROOT / 'package-graph.json').write_text(json.dumps({'root': str(GRAPH), 'top_level': all_top,
    'packages': packages, 'bins': bins, 'issues': issues, 'non_packages_skipped_by_existing_loop': non_packages,
    'composition_loaded_after_attachment': str(KEEPER / '.public13-effective-ordinary/node-modules/@banodoco/timeline-composition'),
    'composition_shared_original': info('/home/user/work/app/node_modules/@banodoco/timeline-composition/package.json')}, indent=2) + '\n')
assert not issues, issues

tools = {}
for name in ['node', 'npm', 'python3', 'git', 'sh', 'bash', 'tar', 'sha256sum', 'cut', 'sed', 'wc', 'grep',
             'awk', 'df', 'realpath', 'readlink', 'mktemp', 'mkdir', 'ln', 'unlink', 'find', 'date', 'cat', 'sort', 'cp',
             'flock', 'openssl', 'ffmpeg']:
    resolved = shutil.which(name)
    tools[name] = info(resolved) if resolved else {'missing': True}
versions = [command(*args) for args in [('node', '--version'), ('npm', '--version'), ('python3', '--version'),
    ('/usr/bin/python3', '--version'), ('/home/user/work/venv-app2-native/bin/python', '--version'),
    ('git', '--version'), ('tar', '--version'), ('flock', '--version'), ('openssl', 'version')]]
repos = {}
for label, repo, ref in [('app', str(KEEPER), '5863411a8c2400db719b5385002b05af0a2b3891'),
    ('agent', '/home/user/peteromallet/astrid-agent', '8130a401bf44a518d5a40ae274d398b8c560be55'),
    ('runtime', '/home/user/banodoco/banodoco-workspace-runtime', '2c4ac180c2220bdad966bc01e95ad230e99ce26a')]:
    repos[label] = {'path': repo, 'ref': ref,
        'identity': command('git', '-C', repo, 'show', '-s', '--format=%H %T %P', ref),
        'status': command('git', '-C', repo, 'status', '--porcelain=v1', '--untracked-files=all')}
    tree = subprocess.check_output(['git', '-C', repo, 'ls-tree', '-r', ref], text=True)
    (ROOT / (label + '-source-tree.tsv')).write_text(tree)
environment = {key: os.environ.get(key) for key in ['PATH', 'TMPDIR', 'NODE_PATH', 'NODE_OPTIONS',
    'PUBLIC13_PREFLIGHT_ONLY', 'PUBLIC13_BUILD_ONLY', 'PUBLIC13_BUILD_PREFLIGHT_PASS', 'PRODUCER_PUBLIC13_NPM_FORWARDER',
    'ASTRID_APP_DIRECT_DOOR_PORT', 'ASTRID_APP_DIRECT_ORIGIN_PORT', 'PLAYWRIGHT_PORT', 'PLAYWRIGHT_BASE_URL']}
disk = shutil.disk_usage(KEEPER)
(ROOT / 'environment.json').write_text(json.dumps({'tools': tools, 'versions': versions, 'repos': repos,
    'environment_allowlist': environment, 'free_kib': disk.free // 1024, 'floor_kib': 10485760,
    'browser_not_executed': info('/opt/pw-browsers/chromium-1194/chrome-linux/chrome'),
    'venv': info('/home/user/work/venv-app2-native/pyvenv.cfg'),
    'lock_not_acquired': info('/home/user/work/.app-m1-browser.lock'),
    'private_run_root_absent': not (KEEPER / '.public13-effective-ordinary').exists(),
    'dist_absent': not (KEEPER / 'dist').exists()}, indent=2) + '\n')
print(f'PASS 51 identity/hash entries, 20 path bindings (one future evidence path), 1 cohort version, 77 archive files, {len(packages)} resolved packages, all declared bins')
