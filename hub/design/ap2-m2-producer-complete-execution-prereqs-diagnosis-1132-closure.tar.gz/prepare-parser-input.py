"""Temporary read-only parser input from frozen Git blobs; no checkout."""
from pathlib import Path
import base64
import json
import subprocess

root = Path(__file__).resolve().parent
process = subprocess.Popen(['git', '-C', '/home/user/peteromallet/astrid-agent', 'cat-file', '--batch'],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE)
data = {}
for line in (root / 'agent-source-tree.tsv').read_text().splitlines():
    metadata, name = line.split('\t')
    if Path(name).suffix not in ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.mts', '.json', '.css']:
        continue
    process.stdin.write((metadata.split()[2] + '\n').encode())
    process.stdin.flush()
    size = int(process.stdout.readline().split()[-1])
    data[name] = base64.b64encode(process.stdout.read(size)).decode()
    process.stdout.read(1)
process.stdin.close()
assert process.wait() == 0
(root / 'agent-parse-input.json').write_text(json.dumps(data))
print('Prepared', len(data), 'blobs as parser data; remove agent-parse-input.json after parsing')
