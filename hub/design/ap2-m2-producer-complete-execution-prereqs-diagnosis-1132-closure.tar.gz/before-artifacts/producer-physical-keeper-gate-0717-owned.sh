#!/bin/sh
set -eu

KEEPER=/home/user/work/wt/ap2-m2-producer-helper-expect-import-0717
FINAL_HEAD=6b0267c62aa8773132f1496d5014279e6c1edf61
FINAL_TREE=c1ac3383624322ae8d67b10dee36965670d91cd7
FINAL_WRAPPER_SHA=329cfca7ff6fcc6764e5eaa6cb53ba77a40e6aa842361d0ed6795ca5b4398352
WRAPPER=scripts/testing/run-producer-public13-list.sh
OWN_WRAPPER=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-runner-0717-owned.sh
OWN_WRAPPER_SHA=664ab0c500f5404e637a2524abaaf75937ee4335cc8fc987df91c37f79c11bd8

MODE=${1:?usage: $0 preflight|list|run}
case "$MODE" in
  preflight|list|run) ;;
  *) echo "usage: $0 preflight|list|run" >&2; exit 2 ;;
esac

# The central service may run from a captured checkout. Admit it only when
# its committed identity and wrapper bytes are exactly the protected keeper.
SERVICE_ROOT=$PWD
test "$(git -C "$SERVICE_ROOT" show -s --format=%T HEAD)" = "$FINAL_TREE"
test -z "$(git -C "$SERVICE_ROOT" status --porcelain=v1 --untracked-files=all)"
test "$(git -C "$SERVICE_ROOT" show HEAD:$WRAPPER | sha256sum | cut -d' ' -f1)" = "$FINAL_WRAPPER_SHA"

test -f /tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-helper-expect-import-0717/KEEP
test "$(git -C "$KEEPER" rev-parse HEAD)" = "$FINAL_HEAD"
test "$(git -C "$KEEPER" show -s --format=%T HEAD)" = "$FINAL_TREE"
test -z "$(git -C "$KEEPER" status --porcelain=v1 --untracked-files=all)"
test "$(git -C "$KEEPER" show HEAD:$WRAPPER | sha256sum | cut -d' ' -f1)" = "$FINAL_WRAPPER_SHA"
test "$(sha256sum "$OWN_WRAPPER" | cut -d' ' -f1)" = "$OWN_WRAPPER_SHA"
test "$(git -C "$SERVICE_ROOT" show -s --format=%T HEAD)" = "$(git -C "$KEEPER" show -s --format=%T HEAD)"
test "$(readlink "$KEEPER/node_modules")" = /home/user/work/app/node_modules

cd "$KEEPER"
exec sh "$OWN_WRAPPER" "$KEEPER" "$MODE"
