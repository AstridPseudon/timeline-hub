#!/bin/sh
set -eu

KEEPER=/home/user/work/wt/ap2-m2-producer-helper-expect-import-0717
SOURCE_GATE=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-physical-keeper-gate-0717-owned.sh
STARTUP_GATE=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-startup-only-gate-0717-owned.sh
PROBE=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-startup-only-probe-0717-owned.mts
FORMAT_PROBE=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-startup-module-format-probe-0717-owned.mts
OWN_WRAPPER=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-runner-0717-owned.sh
KEEP=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-helper-expect-import-0717/KEEP
TSX_BIN=$KEEPER/node_modules/.bin/tsx
TSX_CLI=$KEEPER/node_modules/tsx/dist/cli.mjs
TSX_LOADER=$KEEPER/node_modules/tsx/dist/loader.mjs
TSX_PACKAGE=$KEEPER/node_modules/tsx/package.json
WRAPPER=scripts/testing/run-producer-public13-list.sh
AGENT_REPO=/home/user/peteromallet/astrid-agent
RUNTIME_REPO=/home/user/banodoco/banodoco-workspace-runtime
AGENT_SHA=8130a401bf44a518d5a40ae274d398b8c560be55
AGENT_TREE=236c3e57e0265c52b81ba8085de3193026176bff
RUNTIME_SHA=2c4ac180c2220bdad966bc01e95ad230e99ce26a
RUNTIME_TREE=7ab412cc4bcbe517efcfa806e092336390312e18
FINAL_HEAD=6b0267c62aa8773132f1496d5014279e6c1edf61
FINAL_TREE=c1ac3383624322ae8d67b10dee36965670d91cd7
FINAL_WRAPPER_SHA=329cfca7ff6fcc6764e5eaa6cb53ba77a40e6aa842361d0ed6795ca5b4398352
SOURCE_GATE_SHA=88cb8695c850fc2b3da52bfb2151191901e8f19a14c3f1cbace6f4d1a0166a8b
STARTUP_GATE_SHA=3db5151a442811def19711e3a8e0cc63d0e91047e8f29d1480977c45e6f877d2
PROBE_SHA=a062cab11ea3a86ef75ece5a86584d0555040336032ced515d6ac50de9481d8f
FORMAT_PROBE_SHA=d4eeaeb74a582fe9ccb94c1cfba7f66c41ec50eef7823db34f61ed7185e12af3
TSX_SHA=8729ecfb90d9d568939e4190e6f1d3317c946583b7d37a776e0c23a21c021cf8
TSX_CLI_SHA=8729ecfb90d9d568939e4190e6f1d3317c946583b7d37a776e0c23a21c021cf8
TSX_LOADER_SHA=0b1c5b86192772fe9257710e739959cee5947c11ae1f93b61abfaa9b80c6def1
TSX_PACKAGE_SHA=6e764b21991c21595441f82387c1451ccd10a3e7a3f0973cc5e3649a12dea7d2
SPEC_SHA=d91d0c1cce22f68119cd30fcb0a288346474b0ad4b64c84dcee3b730fa468d89
HELPER_SHA=d86721bd680691e29e705900e03862497a7d97b069f2e43c6192d739cbc9e09b
CONFIG_SHA=5b880ceff883abce2575a3a85aaa4eda69d3bcb848768ff0e91f337d50cca4c0
OWN_WRAPPER_SHA=664ab0c500f5404e637a2524abaaf75937ee4335cc8fc987df91c37f79c11bd8

MODE=${1:?usage: $0 preflight|startup|list|run}
case "$MODE" in
  preflight|startup|list|run) ;;
  *) echo "usage: $0 preflight|startup|list|run" >&2; exit 2 ;;
esac

# The test service invokes this gate from its captured App checkout. Capture
# that cwd before any child gate changes directory; keeper identity remains a
# separate HEAD pin below.
SERVICE_ROOT=$PWD
SERVICE_TREE=$(git -C "$SERVICE_ROOT" show -s --format=%T HEAD)
KEEPER_HEAD=$(git -C "$KEEPER" rev-parse HEAD)
KEEPER_TREE=$(git -C "$KEEPER" show -s --format=%T HEAD)

hash_file() { sha256sum -- "$1" | cut -d' ' -f1; }
verify_ref() {
  repo=$1
  commit=$2
  tree=$3
  test "$(git -C "$repo" rev-parse --verify "$commit^{commit}")" = "$commit"
  test "$(git -C "$repo" show -s --format=%T "$commit^{commit}")" = "$tree"
  test -z "$(git -C "$repo" status --porcelain=v1 --untracked-files=all)"
}

test "$KEEPER_HEAD" = "$FINAL_HEAD"
test "$KEEPER_TREE" = "$FINAL_TREE"
test -z "$(git -C "$KEEPER" status --porcelain=v1 --untracked-files=all)"
test -f "$KEEP"
test "$(readlink "$KEEPER/node_modules")" = /home/user/work/app/node_modules
test "$(hash_file "$KEEPER/$WRAPPER")" = "$FINAL_WRAPPER_SHA"
test "$(hash_file "$OWN_WRAPPER")" = "$OWN_WRAPPER_SHA"
test "$(hash_file "$SOURCE_GATE")" = "$SOURCE_GATE_SHA"
test "$(hash_file "$STARTUP_GATE")" = "$STARTUP_GATE_SHA"
test "$(realpath "$PROBE")" = "$PROBE"
test "$(hash_file "$PROBE")" = "$PROBE_SHA"
test "$(realpath "$FORMAT_PROBE")" = "$FORMAT_PROBE"
test "$(hash_file "$FORMAT_PROBE")" = "$FORMAT_PROBE_SHA"
test "$(realpath "$TSX_BIN")" = "$(realpath "$TSX_CLI")"
test "$(hash_file "$TSX_BIN")" = "$TSX_SHA"
test "$(hash_file "$TSX_CLI")" = "$TSX_CLI_SHA"
test "$(hash_file "$TSX_LOADER")" = "$TSX_LOADER_SHA"
test "$(hash_file "$TSX_PACKAGE")" = "$TSX_PACKAGE_SHA"
test "$KEEPER_TREE" = "$SERVICE_TREE"
test "$SERVICE_TREE" = "$FINAL_TREE"
test "$(git -C "$SERVICE_ROOT" show HEAD:$WRAPPER | sha256sum | cut -d' ' -f1)" = "$FINAL_WRAPPER_SHA"
verify_ref "$AGENT_REPO" "$AGENT_SHA" "$AGENT_TREE"
verify_ref "$RUNTIME_REPO" "$RUNTIME_SHA" "$RUNTIME_TREE"
test "$(hash_file "$KEEPER/tests/e2e/local/producer-ownership-current-pin.spec.ts")" = "$SPEC_SHA"
test "$(hash_file "$KEEPER/tests/e2e/local/support/producer-ownership-current-pin.ts")" = "$HELPER_SHA"
test "$(hash_file "$KEEPER/playwright.producer-ownership-current-pin.config.ts")" = "$CONFIG_SHA"

case "$MODE" in
  preflight)
    sh "$SOURCE_GATE" preflight
    (cd "$SERVICE_ROOT" && "$TSX_BIN" "$FORMAT_PROBE" "$SERVICE_ROOT")
    ;;
  startup) exec sh "$STARTUP_GATE" ;;
  list|run) exec sh "$SOURCE_GATE" "$MODE" ;;
esac
