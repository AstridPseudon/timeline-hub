#!/bin/sh
set -eu

KEEPER=/home/user/work/wt/ap2-m2-producer-helper-expect-import-0717
FINAL_HEAD=6b0267c62aa8773132f1496d5014279e6c1edf61
FINAL_TREE=c1ac3383624322ae8d67b10dee36965670d91cd7
FINAL_WRAPPER_SHA=329cfca7ff6fcc6764e5eaa6cb53ba77a40e6aa842361d0ed6795ca5b4398352
OWN_WRAPPER=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-runner-0717-owned.sh
OWN_WRAPPER_SHA=664ab0c500f5404e637a2524abaaf75937ee4335cc8fc987df91c37f79c11bd8
SUCCESSOR_GATE=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-physical-keeper-gate-0717-owned.sh
PROBE=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-durable-failure-evidence-0753/artifacts/producer-startup-only-probe-0717-owned.mts
WRAPPER=scripts/testing/run-producer-public13-list.sh
ORCH=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch
LOCKED_GRAPH="$ORCH/workers/ap2-m2-locked-app-test-graph/artifacts/app-ap2-m2-locked-graph"
AGENT_REPO=/home/user/peteromallet/astrid-agent
RUNTIME_REPO=/home/user/banodoco/banodoco-workspace-runtime
AGENT_SHA=8130a401bf44a518d5a40ae274d398b8c560be55
RUNTIME_SHA=2c4ac180c2220bdad966bc01e95ad230e99ce26a
AGENT_TREE=236c3e57e0265c52b81ba8085de3193026176bff
RUNTIME_TREE=7ab412cc4bcbe517efcfa806e092336390312e18

SERVICE_ROOT=$PWD
test "$(git -C "$SERVICE_ROOT" show -s --format=%T HEAD)" = "$FINAL_TREE"
test -z "$(git -C "$SERVICE_ROOT" status --porcelain=v1 --untracked-files=all)"
test "$(git -C "$SERVICE_ROOT" show HEAD:$WRAPPER | sha256sum | cut -d' ' -f1)" = "$FINAL_WRAPPER_SHA"
test "$(git -C "$KEEPER" rev-parse HEAD)" = "$FINAL_HEAD"
test "$(git -C "$KEEPER" show -s --format=%T HEAD)" = "$FINAL_TREE"
test -z "$(git -C "$KEEPER" status --porcelain=v1 --untracked-files=all)"
test "$(git -C "$KEEPER" show HEAD:$WRAPPER | sha256sum | cut -d' ' -f1)" = "$FINAL_WRAPPER_SHA"
test "$(sha256sum "$OWN_WRAPPER" | cut -d' ' -f1)" = "$OWN_WRAPPER_SHA"
test -f "$ORCH/workers/ap2-m2-producer-helper-expect-import-0717/KEEP"
test "$(readlink "$KEEPER/node_modules")" = /home/user/work/app/node_modules
test -d "$LOCKED_GRAPH/node_modules"

# The source-only preflight is the same committed wrapper gate used by the
# candidate. It must pass before this daemon startup-only qualification runs.
(cd "$SERVICE_ROOT" && sh "$SUCCESSOR_GATE" preflight)

SHORT_ENV_ROOT=$(mktemp -d /tmp/tla-startup-XXXXXX)
test "$(realpath "$SHORT_ENV_ROOT")" = "$SHORT_ENV_ROOT"

cleanup() {
  status=$?
  trap - EXIT HUP INT TERM
  set +e
  find -P "$SHORT_ENV_ROOT" -depth -delete 2>/dev/null || true
  exit "$status"
}
trap cleanup EXIT HUP INT TERM

SHORT_APP_ROOT="$SHORT_ENV_ROOT/a"
RUN_ROOT="$SHORT_ENV_ROOT/.public13-effective-ordinary"
mkdir -p "$SHORT_ENV_ROOT/xdg-cache" "$SHORT_ENV_ROOT/xdg-config"
ln -s "$KEEPER" "$SHORT_APP_ROOT"
mkdir -p "$RUN_ROOT/agent" "$RUN_ROOT/runtime" "$RUN_ROOT/node-modules" \
  "$RUN_ROOT/tmp" "$RUN_ROOT/npm-cache" "$RUN_ROOT/pw-cache" "$RUN_ROOT/browser-output" "$RUN_ROOT/vite-cache"
test "$(realpath "$RUN_ROOT")" = "$RUN_ROOT"

git clone --quiet --shared --no-checkout "$AGENT_REPO" "$RUN_ROOT/agent"
git -C "$RUN_ROOT/agent" reset --hard --quiet "$AGENT_SHA"
git clone --quiet --shared --no-checkout "$RUNTIME_REPO" "$RUN_ROOT/runtime"
git -C "$RUN_ROOT/runtime" reset --hard --quiet "$RUNTIME_SHA"
test "$(git -C "$RUN_ROOT/agent" show -s --format=%T HEAD)" = "$AGENT_TREE"
test "$(git -C "$RUN_ROOT/runtime" show -s --format=%T HEAD)" = "$RUNTIME_TREE"
test -z "$(git -C "$RUN_ROOT/agent" status --porcelain=v1 --untracked-files=all)"
test -z "$(git -C "$RUN_ROOT/runtime" status --porcelain=v1 --untracked-files=all)"

export ASTRID_CHECKOUT="$RUN_ROOT/agent"
export ASTRID_PYTHON=/home/user/work/venv-app2-native/bin/python
export ASTRID_RUNTIME_CHECKOUT="$RUN_ROOT/runtime"
export ASTRID_RUNTIME_PYTHON=/home/user/work/venv-app2-native/bin/python
export TIMELINE_BUNDLE_AGENT_HEAD="$AGENT_SHA"
export TIMELINE_BUNDLE_RUNTIME_HEAD="$RUNTIME_SHA"
export PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers
export PLAYWRIGHT_CHROMIUM_EXECUTABLE=/opt/pw-browsers/chromium-1194/chrome-linux/chrome
export PWTEST_CACHE_DIR="$RUN_ROOT/pw-cache"
export PLAYWRIGHT_OUTPUT_DIR="$RUN_ROOT/browser-output"
export npm_config_cache="$RUN_ROOT/npm-cache"
export VITE_CACHE_DIR="$RUN_ROOT/vite-cache"
export TMPDIR="$(realpath "$SHORT_ENV_ROOT")"
export XDG_CACHE_HOME="$SHORT_ENV_ROOT/xdg-cache"
export XDG_CONFIG_HOME="$SHORT_ENV_ROOT/xdg-config"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONNOUSERSITE=1
export NODE_OPTIONS=--max-old-space-size=4096
unset ASTRID_PUBLIC_CHECKOUT ASTRID_APP_DIRECT_DIST

test "$(realpath "$TMPDIR")" = "$TMPDIR"
cd "$SHORT_APP_ROOT"
"$KEEPER/node_modules/.bin/tsx" "$PROBE" "$SHORT_APP_ROOT"
