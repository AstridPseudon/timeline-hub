#!/bin/sh
set -eu

APP_ROOT=${1:?usage: $0 APP_ROOT ordinary}
RUN_MODE=${2:-ordinary}
case "$APP_ROOT" in
  /*) ;;
  *) echo 'APP_ROOT must be absolute' >&2; exit 2 ;;
esac
test "$RUN_MODE" = ordinary
test -f "$APP_ROOT/package.json"
PREFLIGHT_ONLY=${PUBLIC13_PREFLIGHT_ONLY:-0}
case "$PREFLIGHT_ONLY" in
  0|1) ;;
  *) echo 'PUBLIC13_PREFLIGHT_ONLY must be 0 or 1' >&2; exit 2 ;;
esac

ORCH=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch
LOCKED_GRAPH="$ORCH/workers/ap2-m2-locked-app-test-graph/artifacts/app-ap2-m2-locked-graph"
LOCKED_GRAPH_ARCHIVE="$ORCH/workers/ap2-m2-locked-app-test-graph/artifacts/app-ap2-m2-locked-graph-source.tar"
AGENT_REPO=/home/user/peteromallet/astrid-agent
RUNTIME_REPO=/home/user/banodoco/banodoco-workspace-runtime
AGENT_SHA=8130a401bf44a518d5a40ae274d398b8c560be55
AGENT_TREE=236c3e57e0265c52b81ba8085de3193026176bff
RUNTIME_SHA=2c4ac180c2220bdad966bc01e95ad230e99ce26a
RUNTIME_TREE=7ab412cc4bcbe517efcfa806e092336390312e18
GRAPH_ARCHIVE_SHA=895c628ab0727c8975247310fd0319b0f546a8d032a57072c9e364e20965ca30
COMPOSITION_TARBALL_SHA=9412ae25c306d5118241f4d631e8eecc6eef9b2fb5a98302d40938e9f6d54738
COMPOSITION_PACKAGE_SHA=7c806b078b00bba1593336c49a3d2953b3f8f7afc7fa9919f6d5d7ccc7c1aa61
COMPOSITION_EVALUATION_SHA=e27ed545e9e0c28cf863e7bccd4a720f61e1002e04f2946dd3afca5e5f478155
RETENTION_HELPER=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-new-topology-main-binding-1113/artifacts/producer-retain-failure-artifacts-0753.sh
RETENTION_HELPER_SHA=dab4e885cedbde6273139d3b4350cacdd33020e63773f9c71e0289ab78ddea75

PREFLIGHT_FAILURES=''
PREFLIGHT_CHECKS=0

record_failure() {
  label=$1
  if test -n "$PREFLIGHT_FAILURES"; then
    PREFLIGHT_FAILURES="$PREFLIGHT_FAILURES
"
  fi
  PREFLIGHT_FAILURES="${PREFLIGHT_FAILURES}- ${label}"
}

check() {
  label=$1
  shift
  PREFLIGHT_CHECKS=$((PREFLIGHT_CHECKS + 1))
  if "$@" >/dev/null 2>&1; then
    return 0
  fi
  record_failure "$label"
}

verify_source() {
  repo=$1 sha=$2 tree=$3
  test -d "$repo/.git" \
    && test "$(git -C "$repo" rev-parse --verify "$sha^{commit}" 2>/dev/null)" = "$sha" \
    && test "$(git -C "$repo" show -s --format=%T "$sha^{commit}" 2>/dev/null)" = "$tree" \
    && test -z "$(git -C "$repo" status --porcelain=v1 --untracked-files=all)"
}

check_app_root() { test -d "$APP_ROOT" && test -f "$APP_ROOT/package.json"; }
check_app_clean() { test -z "$(git -C "$APP_ROOT" status --porcelain=v1 --untracked-files=all)"; }
check_agent_source() { verify_source "$AGENT_REPO" "$AGENT_SHA" "$AGENT_TREE"; }
check_runtime_source() { verify_source "$RUNTIME_REPO" "$RUNTIME_SHA" "$RUNTIME_TREE"; }
check_graph_node_modules() {
  test -d "$LOCKED_GRAPH/node_modules" \
    && test "$(realpath "$LOCKED_GRAPH/node_modules")" = "$LOCKED_GRAPH/node_modules"
}
check_graph_archive() { test "$(sha256sum "$LOCKED_GRAPH_ARCHIVE" | cut -d' ' -f1)" = "$GRAPH_ARCHIVE_SHA"; }
check_composition_package() {
  test "$(node -p "require('$LOCKED_GRAPH/node_modules/@banodoco/timeline-composition/package.json').version")" = 0.0.13 \
    && test "$(sha256sum "$LOCKED_GRAPH/node_modules/@banodoco/timeline-composition/package.json" | cut -d' ' -f1)" = "$COMPOSITION_PACKAGE_SHA" \
    && test "$(sha256sum "$LOCKED_GRAPH/node_modules/@banodoco/timeline-composition/dist/evaluation.js" | cut -d' ' -f1)" = "$COMPOSITION_EVALUATION_SHA"
}
check_composition_archive() {
  test "$(tar -xOf "$LOCKED_GRAPH_ARCHIVE" vendor/artifacts/banodoco-timeline-composition-0.0.13.tgz | sha256sum | cut -d' ' -f1)" = "$COMPOSITION_TARBALL_SHA" \
    && test "$(tar -xOf "$LOCKED_GRAPH_ARCHIVE" vendor/artifacts/banodoco-timeline-composition-0.0.13.tgz | tar -tzf - | sed '/\/$/d' | wc -l)" = 77
}
check_app_isolation() {
  test -L "$APP_ROOT/node_modules" \
    && test -n "$(readlink "$APP_ROOT/node_modules")"
}
check_disk() {
  available_kib=$(df -Pk "$APP_ROOT" | awk 'NR == 2 { print $4 }')
  test -n "$available_kib" && test "$available_kib" -ge 10485760
}
check_retention_helper() {
  test "$(realpath "$RETENTION_HELPER")" = "$RETENTION_HELPER" \
    && test "$(sha256sum "$RETENTION_HELPER" | cut -d' ' -f1)" = "$RETENTION_HELPER_SHA"
}

check app-root check_app_root
check app-clean check_app_clean
check agent-source check_agent_source
check runtime-source check_runtime_source
check graph-node-modules check_graph_node_modules
check graph-archive check_graph_archive
check composition-package check_composition_package
check composition-archive check_composition_archive
check app-isolation check_app_isolation
check disk-space check_disk
check retention-helper check_retention_helper

if test "$PREFLIGHT_CHECKS" = 0; then
  record_failure 'no preflight checks executed'
fi
if test -n "$PREFLIGHT_FAILURES"; then
  printf '%s\n%s\n' 'public13 preflight FAIL' "$PREFLIGHT_FAILURES" >&2
  exit 1
fi

RUN_ROOT="$APP_ROOT/.public13-effective-${RUN_MODE}"
case "$RUN_ROOT" in
  "$APP_ROOT"/*) ;;
  *) echo 'unsafe run root' >&2; exit 2 ;;
esac
test ! -e "$RUN_ROOT"
mkdir -p "$RUN_ROOT/agent" "$RUN_ROOT/runtime" "$RUN_ROOT/node-modules" \
  "$RUN_ROOT/tmp" "$RUN_ROOT/npm-cache" "$RUN_ROOT/pw-cache" "$RUN_ROOT/browser-output" "$RUN_ROOT/vite-cache"

test -L "$APP_ROOT/node_modules"
ORIGINAL_NODE_MODULES_TARGET=$(readlink "$APP_ROOT/node_modules")
test -n "$ORIGINAL_NODE_MODULES_TARGET"
ATTACHED_PATHS=''

cleanup() {
  rc=$?
  trap - EXIT HUP INT TERM
  set +e
  retention_rc=0
  if test "$rc" -ne 0; then
    "$RETENTION_HELPER" "$(realpath "$RUN_ROOT")" "${PRODUCER_PUBLIC13_DURABLE_ROOT:?missing durable evidence root}" \
      "${PRODUCER_PUBLIC13_LIST_LOG:?missing child log}" "$rc" "$APP_ROOT" "$RUN_MODE" \
      "$AGENT_SHA" "$RUNTIME_SHA" || {
        retention_rc=$?
        printf 'producer failure retention FAILED status=%s run_root=%s\n' "$retention_rc" "$RUN_ROOT" >&2
      }
  fi
  for path in $ATTACHED_PATHS; do
    unlink "$path"
  done
  ln -s "$ORIGINAL_NODE_MODULES_TARGET" "$APP_ROOT/node_modules"
  if test -d "$APP_ROOT/dist" && test -z "$(git -C "$APP_ROOT" ls-files -- 'dist/**')"; then
    find -P "$APP_ROOT/dist" -depth -delete
  fi
  find "$RUN_ROOT" -depth -delete
  if test "$retention_rc" -ne 0; then
    rc=1
  fi
  exit "$rc"
}
trap cleanup EXIT HUP INT TERM

git clone --quiet --shared --no-checkout "$AGENT_REPO" "$RUN_ROOT/agent"
git -C "$RUN_ROOT/agent" reset --hard --quiet "$AGENT_SHA"
git clone --quiet --shared --no-checkout "$RUNTIME_REPO" "$RUN_ROOT/runtime"
git -C "$RUN_ROOT/runtime" reset --hard --quiet "$RUNTIME_SHA"
test "$(git -C "$RUN_ROOT/agent" show -s --format=%T HEAD)" = "$AGENT_TREE"
test "$(git -C "$RUN_ROOT/runtime" show -s --format=%T HEAD)" = "$RUNTIME_TREE"
test -z "$(git -C "$RUN_ROOT/agent" status --porcelain=v1 --untracked-files=all)"
test -z "$(git -C "$RUN_ROOT/runtime" status --porcelain=v1 --untracked-files=all)"

# Keep the locked graph read-only. Composition is the one package whose loaded
# bytes must not remain a symlink through a shared install; every other package
# is linked from the immutable graph and receives a private bin entry.
SOURCE_NODE_MODULES="$LOCKED_GRAPH/node_modules" PRIVATE_NODE_MODULES="$RUN_ROOT/node-modules" node --input-type=module - <<'JS'
import { cpSync, lstatSync, mkdirSync, readFileSync, readdirSync, realpathSync, symlinkSync } from 'node:fs';
import path from 'node:path';

const source = realpathSync(process.env.SOURCE_NODE_MODULES);
const destination = path.resolve(process.env.PRIVATE_NODE_MODULES);
const composition = '@banodoco/timeline-composition';
mkdirSync(path.join(destination, '.bin'), { recursive: true });
const packages = [];
for (const entry of readdirSync(source, { withFileTypes: true })) {
  if (entry.name === '.bin') continue;
  const scoped = entry.name.startsWith('@');
  const sourceScope = path.join(source, entry.name);
  const destinationScope = path.join(destination, entry.name);
  if (scoped) mkdirSync(destinationScope);
  const entries = scoped ? readdirSync(sourceScope, { withFileTypes: true }) : [entry];
  for (const packageEntry of entries) {
    if (packageEntry.name === '.bin') continue;
    const name = scoped ? `${entry.name}/${packageEntry.name}` : entry.name;
    const sourcePackage = scoped ? path.join(sourceScope, packageEntry.name) : sourceScope;
    const destinationPackage = scoped ? path.join(destinationScope, packageEntry.name) : path.join(destination, entry.name);
    if (name === composition) cpSync(sourcePackage, destinationPackage, { recursive: true, dereference: true, errorOnExist: true });
    else symlinkSync(sourcePackage, destinationPackage, 'dir');
    packages.push([name, destinationPackage]);
  }
}
for (const [name, packageDirectory] of packages) {
  let packageJson;
  try { packageJson = JSON.parse(readFileSync(path.join(packageDirectory, 'package.json'), 'utf8')); }
  catch (error) { if (error?.code === 'ENOENT') continue; throw error; }
  const declaration = packageJson.bin;
  if (!declaration) continue;
  const declared = typeof declaration === 'string' ? { [String(packageJson.name ?? name).split('/').pop()]: declaration } : declaration;
  for (const [command, target] of Object.entries(declared)) {
    if (!command || typeof target !== 'string' || !target) throw new Error(`invalid bin declaration in ${name}`);
    const resolvedTarget = path.resolve(packageDirectory, target);
    const packageRoot = path.resolve(packageDirectory);
    if (resolvedTarget !== packageRoot && !resolvedTarget.startsWith(`${packageRoot}${path.sep}`)) throw new Error(`bin target escapes ${name}`);
    lstatSync(resolvedTarget);
    const link = path.join(destination, '.bin', command);
    if (!lstatSync(link, { throwIfNoEntry: false })) symlinkSync(path.relative(path.join(destination, '.bin'), resolvedTarget), link);
  }
}
JS
test -x "$RUN_ROOT/node-modules/.bin/vite"
test -x "$RUN_ROOT/node-modules/.bin/playwright"
test "$(sha256sum "$RUN_ROOT/node-modules/@banodoco/timeline-composition/package.json" | cut -d' ' -f1)" = "$COMPOSITION_PACKAGE_SHA"
test "$(sha256sum "$RUN_ROOT/node-modules/@banodoco/timeline-composition/dist/evaluation.js" | cut -d' ' -f1)" = "$COMPOSITION_EVALUATION_SHA"

attach_private_graph() {
  path=$1
  test ! -e "$path" && test ! -L "$path"
  ln -s "$RUN_ROOT/node-modules" "$path"
  ATTACHED_PATHS="$ATTACHED_PATHS $path"
}
unlink "$APP_ROOT/node_modules"
ln -s "$RUN_ROOT/node-modules" "$APP_ROOT/node_modules"
ATTACHED_PATHS="$APP_ROOT/node_modules"
attach_private_graph "$RUN_ROOT/agent/node_modules"
attach_private_graph "$RUN_ROOT/agent/remotion/node_modules"

export ASTRID_CHECKOUT="$RUN_ROOT/agent"
export ASTRID_PYTHON=/home/user/work/venv-app2-native/bin/python
export ASTRID_RUNTIME_CHECKOUT="$RUN_ROOT/runtime"
export ASTRID_RUNTIME_PYTHON=/home/user/work/venv-app2-native/bin/python
export TIMELINE_BUNDLE_AGENT_HEAD="$AGENT_SHA"
export TIMELINE_BUNDLE_RUNTIME_HEAD="$RUNTIME_SHA"
export PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers
export PLAYWRIGHT_CHROMIUM_EXECUTABLE=/opt/pw-browsers/chromium-1194/chrome-linux/chrome
export PWTEST_CACHE_DIR="$RUN_ROOT/pw-cache"
export PLAYWRIGHT_OUTPUT_DIR="$RUN_ROOT/browser-output"
export npm_config_cache="$RUN_ROOT/npm-cache"
export VITE_CACHE_DIR="$RUN_ROOT/vite-cache"
export TMPDIR="$RUN_ROOT/tmp"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONNOUSERSITE=1
export NODE_OPTIONS=--max-old-space-size=4096
unset ASTRID_PUBLIC_CHECKOUT ASTRID_APP_DIRECT_DIST

APP_ROOT="$APP_ROOT" PRIVATE_NODE_MODULES="$RUN_ROOT/node-modules" LOCKED_GRAPH="$LOCKED_GRAPH" AGENT_ROOT="$RUN_ROOT/agent" \
  EXPECTED_TARBALL_SHA="$COMPOSITION_TARBALL_SHA" EXPECTED_PACKAGE_SHA="$COMPOSITION_PACKAGE_SHA" \
  EXPECTED_EVALUATION_SHA="$COMPOSITION_EVALUATION_SHA" node --input-type=module - <<'JS'
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFileSync, realpathSync } from 'node:fs';
import path from 'node:path';
import { resolveConfig } from 'vite';

const appRoot = path.resolve(process.env.APP_ROOT);
const privateNodeModules = path.resolve(process.env.PRIVATE_NODE_MODULES);
const packageRoot = path.join(privateNodeModules, '@banodoco', 'timeline-composition');
const packageJsonPath = path.join(packageRoot, 'package.json');
const evaluationPath = path.join(packageRoot, 'dist', 'evaluation.js');
const sha256 = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const expectedPackageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'));
assert.equal(expectedPackageJson.version, '0.0.13');
assert.equal(sha256(packageJsonPath), process.env.EXPECTED_PACKAGE_SHA);
assert.equal(sha256(evaluationPath), process.env.EXPECTED_EVALUATION_SHA);

function assertResolved(importer, label) {
  const require = createRequire(importer);
  const manifest = realpathSync(require.resolve('@banodoco/timeline-composition/package.json'));
  const evaluation = realpathSync(require.resolve('@banodoco/timeline-composition/evaluation'));
  assert.equal(manifest, realpathSync(packageJsonPath), `${label} manifest`);
  assert.equal(evaluation, realpathSync(evaluationPath), `${label} evaluation`);
  assert.equal(JSON.parse(readFileSync(manifest, 'utf8')).version, '0.0.13', `${label} version`);
  return { manifest, evaluation };
}

const appImporter = path.join(appRoot, 'src/tools/video-editor/compositions/playerEvaluation.ts');
const sdkImporter = path.join(process.env.AGENT_ROOT, 'remotion/src/ThreeTimelineComposition.tsx');
assertResolved(path.join(appRoot, 'package.json'), 'App createRequire');
assertResolved(path.join(process.env.AGENT_ROOT, 'remotion/package.json'), 'SDK createRequire');
const config = await resolveConfig({ configFile: path.join(appRoot, 'config/vite/vite.config.ts') }, 'build');
const resolver = config.createResolver();
for (const [importer, label] of [[appImporter, 'App Vite'], [sdkImporter, 'SDK Vite']]) {
  const resolved = await resolver('@banodoco/timeline-composition/evaluation', importer);
  assert.equal(realpathSync(resolved), realpathSync(evaluationPath), `${label} resolver`);
}
const evaluation = await import(`file://${evaluationPath}`);
assert.equal(typeof evaluation.clipOpacity, 'function', 'public13 clipOpacity export');
console.log(`public13 hosted-build resolver PASS version=0.0.13 package=${packageJsonPath} evaluation=${evaluationPath} tarball_sha256=${process.env.EXPECTED_TARBALL_SHA}`);
JS

if test "$PREFLIGHT_ONLY" = 1; then
  printf '%s\n' "public13 preflight PASS checks=$PREFLIGHT_CHECKS source=agent:$AGENT_SHA runtime:$RUNTIME_SHA graph=public13 isolation=private"
  exit 0
fi

flock -w 600 /home/user/work/.app-m1-browser.lock sh -c '
  cd "$1"
  npm run build:hosted
  test -f dist/index.html
  if test "${PUBLIC13_BUILD_ONLY:-0}" = 1; then
    printf "%s\n" "public13 hosted build preflight PASS"
    exit 0
  fi
  test "${PUBLIC13_BUILD_PREFLIGHT_PASS:-0}" = 1
  npm run test:e2e:three-products -- --grep "M2 ordinary extension batch"
' sh "$APP_ROOT"
