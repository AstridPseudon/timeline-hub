#!/bin/sh
set -eu

KEEPER=/home/user/work/wt/app-pin-5863411a
FINAL_HEAD=5863411a8c2400db719b5385002b05af0a2b3891
FINAL_TREE=31b0f77c6ef4e9fdbeff3e4f88cc4705f0891e89
FINAL_WRAPPER_SHA=329cfca7ff6fcc6764e5eaa6cb53ba77a40e6aa842361d0ed6795ca5b4398352
WRAPPER=scripts/testing/run-producer-public13-list.sh
OWN_WRAPPER=/tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/ap2-m2-producer-new-topology-main-binding-1113/artifacts/producer-runner-0717-owned.sh
OWN_WRAPPER_SHA=7bb7cbf017f62cefe2e06c5d4eed860822c0be0af8894dedd95cb75fa7f87f17

MODE=${1:?usage: $0 preflight|list|run}
case "$MODE" in
  preflight|list|run) ;;
  *) echo "usage: $0 preflight|list|run" >&2; exit 2 ;;
esac

# The central service may run from a captured checkout. Admit it only when
# its committed identity and wrapper bytes are exactly the protected keeper.
SERVICE_ROOT=$PWD
test "$(git -C "$SERVICE_ROOT" show -s --format=%T HEAD)" = "$FINAL_TREE"
test -z "$(git -C "$SERVICE_ROOT" status --porcelain=v1 --untracked-files=all)"
test "$(git -C "$SERVICE_ROOT" show HEAD:$WRAPPER | sha256sum | cut -d' ' -f1)" = "$FINAL_WRAPPER_SHA"

test -f /tmp/claude-0/-home-user-repo/7dc61be1-7066-52e0-a5d0-94f90e61430a/scratchpad/orch/workers/app-pin-5863411a/KEEP
test "$(git -C "$KEEPER" rev-parse HEAD)" = "$FINAL_HEAD"
test "$(git -C "$KEEPER" show -s --format=%T HEAD)" = "$FINAL_TREE"
test -z "$(git -C "$KEEPER" status --porcelain=v1 --untracked-files=all)"
test "$(git -C "$KEEPER" show HEAD:$WRAPPER | sha256sum | cut -d' ' -f1)" = "$FINAL_WRAPPER_SHA"
test "$(sha256sum "$OWN_WRAPPER" | cut -d' ' -f1)" = "$OWN_WRAPPER_SHA"
test "$(git -C "$SERVICE_ROOT" show -s --format=%T HEAD)" = "$(git -C "$KEEPER" show -s --format=%T HEAD)"
test "$(readlink "$KEEPER/node_modules")" = /home/user/work/app/node_modules

cd "$KEEPER"
exec sh "$OWN_WRAPPER" "$KEEPER" "$MODE"
